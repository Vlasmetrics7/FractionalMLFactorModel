library(fracdiff)
library(forecast)
library(readxl)
library(MCS)

#####################################
############ REGION 1 ###############
#####################################

Orig <- read_excel("~R1.xlsx",sheet = 'Orig')
M1a <- read_excel("~R1.xlsx",sheet = 'M1a')
M1b <- read_excel("~R1.xlsx",sheet = 'M1b')
M2a <- read_excel("~R1.xlsx",sheet = 'M2a')
M2b <- read_excel("~R1.xlsx",sheet = 'M2b')
M3a <- read_excel("~R1.xlsx",sheet = 'M3a')
M3b <- read_excel("~R1.xlsx",sheet = 'M3b')
M4a <- read_excel("~R1.xlsx",sheet = 'M4a')
M4b <- read_excel("~R1.xlsx",sheet = 'M4b')
M5a <- read_excel("~R1.xlsx",sheet = 'M5a')
M5b <- read_excel("~R1.xlsx",sheet = 'M5b')
M6a <- read_excel("~R1.xlsx",sheet = 'M6a')
M6b <- read_excel("~R1.xlsx",sheet = 'M6b')

#####################

dP <- data.matrix(Orig)
RegPri <- data.matrix(Orig)
Price<- dP[1006:1096,]

dP <- data.matrix(M1a)
M1<- dP[1:91,]
dP <- data.matrix(M1b)
M2<- dP[1:91,]
dP <- data.matrix(M2a)
M3<- dP[1:91,]
dP <- data.matrix(M2b)
M4<- dP[1:91,]
dP <- data.matrix(M3a)
M5<- dP[1:91,]
dP <- data.matrix(M3b)
M6<- dP[1:91,]
dP <- data.matrix(M4a)
M7<- dP[1:91,]
dP <- data.matrix(M4b)
M8<- dP[1:91,]
dP <- data.matrix(M5a)
M9<- dP[1:91,]
dP <- data.matrix(M5b)
M10<- dP[1:91,]
dP <- data.matrix(M6a)
M11<- dP[1:91,]
dP <- data.matrix(M6b)
M12<- dP[1:91,]

#######################
T =1096 # FULL SAMPLE
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=matrix(0,91,48)
HOR=1

for (j in 1:48) {
  for(Ewind in T0:(T-1)){
    # ROLLING WINDOWS MODELOS 0 
    RW=rwf(RegPri[(Ewind-T0+1):Ewind,j], h = HOR, drift = FALSE, level = c(95))
    FM1[Ewind-T0,j]=RW$mean[HOR]
    
    ForM0 =predict(arima(RegPri[(Ewind-T0+1):Ewind,j],order=c(1,1,1)),HOR)
    FM2[Ewind-T0,j]=ForM0$pred[HOR]
    
    Mod1 =arfima(RegPri[(Ewind-T0+1):Ewind,j],drange=c(0.3,0.5),estim="mle")
    ForM1=forecast(Mod1,h=HOR)
    FM3[Ewind-T0,j]=ForM1$mean[HOR]
  }}

####################

Loss_M1<-matrix(0,91,48)
Loss_M2<-matrix(0,91,48)
Loss_M3<-matrix(0,91,48)
Loss_M4<-matrix(0,91,48)
Loss_M5<-matrix(0,91,48)
Loss_M6<-matrix(0,91,48)
Loss_M7<-matrix(0,91,48)
Loss_M8<-matrix(0,91,48)
Loss_M9<-matrix(0,91,48)
Loss_M10<-matrix(0,91,48)
Loss_M11<-matrix(0,91,48)
Loss_M12<-matrix(0,91,48)
Loss_M13<-matrix(0,91,48)
Loss_M14<-matrix(0,91,48)
Loss_M15<-matrix(0,91,48)

for(j in 1:48){
  Loss_M1[,j]=LossLevel(Price[,j], M1[,j], which = "AE")
  Loss_M2[,j]=LossLevel(Price[,j], M2[,j], which = "AE")
  Loss_M3[,j]=LossLevel(Price[,j], M3[,j], which = "AE")
  Loss_M4[,j]=LossLevel(Price[,j], M4[,j], which = "AE")
  Loss_M5[,j]=LossLevel(Price[,j], M5[,j], which = "AE")
  Loss_M6[,j]=LossLevel(Price[,j], M6[,j], which = "AE")
  Loss_M7[,j]=LossLevel(Price[,j], M7[,j], which = "AE")
  Loss_M8[,j]=LossLevel(Price[,j], M8[,j], which = "AE")
  Loss_M9[,j]=LossLevel(Price[,j], M9[,j], which = "AE")
  Loss_M10[,j]=LossLevel(Price[,j], M10[,j], which = "AE")
  Loss_M11[,j]=LossLevel(Price[,j], M11[,j], which = "AE")
  Loss_M12[,j]=LossLevel(Price[,j], M12[,j], which = "AE")
  Loss_M13[,j]=LossLevel(Price[,j], FM1[,j], which = "AE")
  Loss_M14[,j]=LossLevel(Price[,j], FM2[,j], which = "AE")
  Loss_M15[,j]=LossLevel(Price[,j], FM3[,j], which = "AE")
}

BEST=0
for(j in 3:4){
  LH1=cbind(Loss_M1[,j],Loss_M2[,j],Loss_M3[,j],Loss_M4[,j],Loss_M5[,j],Loss_M6[,j],Loss_M7[,j],Loss_M8[,j],Loss_M9[,j],Loss_M10[,j],Loss_M11[,j],Loss_M12[,j],Loss_M13[,j],Loss_M14[,j],Loss_M15[,j])
  MCS <- MCSprocedure(Loss=LH1,alpha=0.20,B=5000,statistic='TR',verbose = TRUE)
  #BEST[j]=which.min(MCS@show[,1])
}

aRMSE1=aRMSE2=aRMSE3=aRMSE4=aRMSE5=aRMSE6=aRMSE7=aRMSE8=aRMSE9=aRMSE10=aRMSE11=aRMSE12=aRMSE13=aRMSE14=aRMSE15=0
for(j in 1:48){
  aRMSE1[j]=sqrt(mean(Loss_M1[,j]))
  aRMSE2[j]=sqrt(mean(Loss_M2[,j]))
  aRMSE3[j]=sqrt(mean(Loss_M3[,j]))
  aRMSE4[j]=sqrt(mean(Loss_M4[,j]))
  aRMSE5[j]=sqrt(mean(Loss_M5[,j]))
  aRMSE6[j]=sqrt(mean(Loss_M6[,j]))
  aRMSE7[j]=sqrt(mean(Loss_M7[,j]))
  aRMSE8[j]=sqrt(mean(Loss_M8[,j]))
  aRMSE9[j]=sqrt(mean(Loss_M9[,j]))
  aRMSE10[j]=sqrt(mean(Loss_M10[,j]))
  aRMSE11[j]=sqrt(mean(Loss_M11[,j]))
  aRMSE12[j]=sqrt(mean(Loss_M12[,j]))
  aRMSE13[j]=sqrt(mean(Loss_M13[,j]))
  aRMSE14[j]=sqrt(mean(Loss_M14[,j]))
  aRMSE15[j]=sqrt(mean(Loss_M15[,j]))
}

RMSE=rbind(aRMSE1,aRMSE2,aRMSE3,aRMSE4,aRMSE5,aRMSE6,aRMSE7,aRMSE8,aRMSE9,aRMSE10,aRMSE11,aRMSE12,aRMSE13,aRMSE14,aRMSE15)

RMSE

##############################################################
##############################################################
##############################################################

e_M1<-matrix(0,91,48)
e_M2<-matrix(0,91,48)
e_M3<-matrix(0,91,48)
e_M4<-matrix(0,91,48)
e_M5<-matrix(0,91,48)
e_M6<-matrix(0,91,48)
e_M7<-matrix(0,91,48)
e_M8<-matrix(0,91,48)
e_M9<-matrix(0,91,48)
e_M10<-matrix(0,91,48)
e_M11<-matrix(0,91,48)
e_M12<-matrix(0,91,48)
e_M13<-matrix(0,91,48)
e_M14<-matrix(0,91,48)
e_M15<-matrix(0,91,48)


for(j in 1:48){
  e_M1[,j]= M1[,j]-Price[,j]
  e_M2[,j]=M2[,j]-Price[,j]
  e_M3[,j]=M3[,j]-Price[,j]
  e_M4[,j]=M4[,j]-Price[,j]
  e_M5[,j]= M5[,j]-Price[,j]
  e_M6[,j]=M6[,j]-Price[,j]
  e_M7[,j]=M7[,j]-Price[,j]
  e_M8[,j]=M8[,j]-Price[,j]
  e_M9[,j]= M9[,j]-Price[,j]
  e_M10[,j]=M10[,j]-Price[,j]
  e_M11[,j]=M11[,j]-Price[,j]
  e_M12[,j]=M12[,j]-Price[,j]
  e_M13[,j]= FM1[,j]-Price[,j]
  e_M14[,j]=FM2[,j]-Price[,j]
  e_M15[,j]=FM3[,j]-Price[,j]
}

DM_RSULTS<-matrix(0,14,48)
for(k in 1:48){
DM1=dm.test(e_M1[,k],e_M2[,k],alternative = "less",h = 1,power = 1)
DM2=dm.test(e_M1[,k],e_M3[,k],alternative = "less",h = 1,power = 1)
DM3=dm.test(e_M1[,k],e_M4[,k],alternative = "less",h = 1,power = 1)
DM4=dm.test(e_M1[,k],e_M5[,k],alternative = "less",h = 1,power = 1)
DM5=dm.test(e_M1[,k],e_M6[,k],alternative = "less",h = 1,power = 1)
DM6=dm.test(e_M1[,k],e_M7[,k],alternative = "less",h = 1,power = 1)
DM7=dm.test(e_M1[,k],e_M8[,k],alternative = "less",h = 1,power = 1)
DM8=dm.test(e_M1[,k],e_M9[,k],alternative = "less",h = 1,power = 1)
DM9=dm.test(e_M1[,k],e_M10[,k],alternative = "less",h = 1,power = 1)
DM10=dm.test(e_M1[,k],e_M11[,k],alternative = "less",h = 1,power = 1)
DM11=dm.test(e_M1[,k],e_M12[,k],alternative = "less",h = 1,power = 1)
DM12=dm.test(e_M1[,k],e_M13[,k],alternative = "less",h = 1,power = 1)
DM13=dm.test(e_M1[,k],e_M14[,k],alternative = "less",h = 1,power = 1)
DM14=dm.test(e_M1[,k],e_M15[,k],alternative = "less",h = 1,power = 1)

DM_RSULTS[,k]=round(rbind(DM1$p.value,DM2$p.value,DM3$p.value,DM4$p.value,DM5$p.value,
            DM6$p.value,DM7$p.value,DM8$p.value,DM9$p.value,DM10$p.value,
            DM11$p.value,DM12$p.value,DM13$p.value,DM14$p.value),3)
}

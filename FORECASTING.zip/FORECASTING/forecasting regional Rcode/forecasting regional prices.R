library(fracdiff)
library(forecast)
library(readxl)
library(MCS)

#####################################
############ REGION 1 ###############
#####################################

Orig <- read_excel("~R1.xlsx",sheet = 'Orig')
M1a <- read_excel("~R1.xlsx",sheet = 'M1a')
M1b <- read_excel("~R1.xlsx",sheet = 'M1b')
M2a <- read_excel("~R1.xlsx",sheet = 'M2a')
M2b <- read_excel("~R1.xlsx",sheet = 'M2b')
M3a <- read_excel("~R1.xlsx",sheet = 'M3a')
M3b <- read_excel("~R1.xlsx",sheet = 'M3b')
M4a <- read_excel("~R1.xlsx",sheet = 'M4a')
M4b <- read_excel("~R1.xlsx",sheet = 'M4b')
M5a <- read_excel("~R1.xlsx",sheet = 'M5a')
M5b <- read_excel("~R1.xlsx",sheet = 'M5b')
M6a <- read_excel("~R1.xlsx",sheet = 'M6a')
M6b <- read_excel("~R1.xlsx",sheet = 'M6b')


#####################

dP <- data.matrix(Orig)
RegPri <- data.matrix(Orig)
Price<- dP[1006:1096,]

dP <- data.matrix(M1a)
M1<- dP[1:91,]
dP <- data.matrix(M1b)
M2<- dP[1:91,]
dP <- data.matrix(M2a)
M3<- dP[1:91,]
dP <- data.matrix(M2b)
M4<- dP[1:91,]
dP <- data.matrix(M3a)
M5<- dP[1:91,]
dP <- data.matrix(M3b)
M6<- dP[1:91,]
dP <- data.matrix(M4a)
M7<- dP[1:91,]
dP <- data.matrix(M4b)
M8<- dP[1:91,]
dP <- data.matrix(M5a)
M9<- dP[1:91,]
dP <- data.matrix(M5b)
M10<- dP[1:91,]
dP <- data.matrix(M6a)
M11<- dP[1:91,]
dP <- data.matrix(M6b)
M12<- dP[1:91,]

#######################
T =1096 # FULL SAMPLE
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=matrix(0,91,48)
HOR=1

for (j in 1:48) {
for(Ewind in T0:(T-1)){
  # ROLLING WINDOWS MODELOS 0 
  RW=rwf(RegPri[(Ewind-T0+1):Ewind,j], h = HOR, drift = FALSE, level = c(95))
  FM1[Ewind-T0,j]=RW$mean[HOR]
  
  ForM0 =predict(arima(RegPri[(Ewind-T0+1):Ewind,j],order=c(1,1,1)),HOR)
  FM2[Ewind-T0,j]=ForM0$pred[HOR]
  
  Mod1 =arfima(RegPri[(Ewind-T0+1):Ewind,j],drange=c(0.3,0.5),estim="mle")
  ForM1=forecast(Mod1,h=HOR)
  FM3[Ewind-T0,j]=ForM1$mean[HOR]
}}

####################

Loss_M1<-matrix(0,91,48)
Loss_M2<-matrix(0,91,48)
Loss_M3<-matrix(0,91,48)
Loss_M4<-matrix(0,91,48)
Loss_M5<-matrix(0,91,48)
Loss_M6<-matrix(0,91,48)
Loss_M7<-matrix(0,91,48)
Loss_M8<-matrix(0,91,48)
Loss_M9<-matrix(0,91,48)
Loss_M10<-matrix(0,91,48)
Loss_M11<-matrix(0,91,48)
Loss_M12<-matrix(0,91,48)
Loss_M13<-matrix(0,91,48)
Loss_M14<-matrix(0,91,48)
Loss_M15<-matrix(0,91,48)

for(j in 1:48){
Loss_M1[,j]=LossLevel(Price[,j], M1[,j], which = "SE")
Loss_M2[,j]=LossLevel(Price[,j], M2[,j], which = "SE")
Loss_M3[,j]=LossLevel(Price[,j], M3[,j], which = "SE")
Loss_M4[,j]=LossLevel(Price[,j], M4[,j], which = "SE")
Loss_M5[,j]=LossLevel(Price[,j], M5[,j], which = "SE")
Loss_M6[,j]=LossLevel(Price[,j], M6[,j], which = "SE")
Loss_M7[,j]=LossLevel(Price[,j], M7[,j], which = "SE")
Loss_M8[,j]=LossLevel(Price[,j], M8[,j], which = "SE")
Loss_M9[,j]=LossLevel(Price[,j], M9[,j], which = "SE")
Loss_M10[,j]=LossLevel(Price[,j], M10[,j], which = "SE")
Loss_M11[,j]=LossLevel(Price[,j], M11[,j], which = "SE")
Loss_M12[,j]=LossLevel(Price[,j], M12[,j], which = "SE")
Loss_M13[,j]=LossLevel(Price[,j], FM1[,j], which = "SE")
Loss_M14[,j]=LossLevel(Price[,j], FM2[,j], which = "SE")
Loss_M15[,j]=LossLevel(Price[,j], FM3[,j], which = "SE")
}

BEST=0
for(j in 1:48){
LH1=cbind(Loss_M1[,j],Loss_M2[,j],Loss_M3[,j],Loss_M4[,j],Loss_M5[,j],Loss_M6[,j],Loss_M7[,j],Loss_M8[,j],Loss_M9[,j],Loss_M10[,j],Loss_M11[,j],Loss_M12[,j],Loss_M13[,j],Loss_M14[,j],Loss_M15[,j])
MCS <- MCSprocedure(Loss=LH1,alpha=0.20,B=5000,statistic='TR',verbose = FALSE)
BEST[j]=which.min(MCS@show[,1])
}

aRMSE1=aRMSE2=aRMSE3=aRMSE4=aRMSE5=aRMSE6=aRMSE7=aRMSE8=aRMSE9=aRMSE10=aRMSE11=aRMSE12=aRMSE13=aRMSE14=aRMSE15=0
for(j in 1:48){
  aRMSE1[j]=sqrt(mean(Loss_M1[,j]))
  aRMSE2[j]=sqrt(mean(Loss_M2[,j]))
  aRMSE3[j]=sqrt(mean(Loss_M3[,j]))
  aRMSE4[j]=sqrt(mean(Loss_M4[,j]))
  aRMSE5[j]=sqrt(mean(Loss_M5[,j]))
  aRMSE6[j]=sqrt(mean(Loss_M6[,j]))
  aRMSE7[j]=sqrt(mean(Loss_M7[,j]))
  aRMSE8[j]=sqrt(mean(Loss_M8[,j]))
  aRMSE9[j]=sqrt(mean(Loss_M9[,j]))
  aRMSE10[j]=sqrt(mean(Loss_M10[,j]))
  aRMSE11[j]=sqrt(mean(Loss_M11[,j]))
  aRMSE12[j]=sqrt(mean(Loss_M12[,j]))
  }

RMSE=rbind(mean(aRMSE1),mean(aRMSE2),mean(aRMSE3),mean(aRMSE4),mean(aRMSE5),mean(aRMSE6),mean(aRMSE7),mean(aRMSE8),mean(aRMSE9),mean(aRMSE10),mean(aRMSE11),mean(aRMSE12))

RMSE




#####################################
############ REGION 2 ###############
#####################################

Orig <- read_excel("~R2.xlsx",sheet = 'Orig')
M1a <- read_excel("~R2.xlsx",sheet = 'M1a')
M1b <- read_excel("~R2.xlsx",sheet = 'M1b')
M2a <- read_excel("~R2.xlsx",sheet = 'M2a')
M2b <- read_excel("~R2.xlsx",sheet = 'M2b')
M3a <- read_excel("~R2.xlsx",sheet = 'M3a')
M3b <- read_excel("~R2.xlsx",sheet = 'M3b')
M4a <- read_excel("~R2.xlsx",sheet = 'M4a')
M4b <- read_excel("~R2.xlsx",sheet = 'M4b')
M5a <- read_excel("~R2.xlsx",sheet = 'M5a')
M5b <- read_excel("~R2.xlsx",sheet = 'M5b')
M6a <- read_excel("~R2.xlsx",sheet = 'M6a')
M6b <- read_excel("~R2.xlsx",sheet = 'M6b')


#####################

dP <- data.matrix(Orig)
RegPri <- data.matrix(Orig)
Price<- dP[1006:1096,]

dP <- data.matrix(M1a)
M1<- dP[1:91,]
dP <- data.matrix(M1b)
M2<- dP[1:91,]
dP <- data.matrix(M2a)
M3<- dP[1:91,]
dP <- data.matrix(M2b)
M4<- dP[1:91,]
dP <- data.matrix(M3a)
M5<- dP[1:91,]
dP <- data.matrix(M3b)
M6<- dP[1:91,]
dP <- data.matrix(M4a)
M7<- dP[1:91,]
dP <- data.matrix(M4b)
M8<- dP[1:91,]
dP <- data.matrix(M5a)
M9<- dP[1:91,]
dP <- data.matrix(M5b)
M10<- dP[1:91,]
dP <- data.matrix(M6a)
M11<- dP[1:91,]
dP <- data.matrix(M6b)
M12<- dP[1:91,]

#######################
T =1096 # FULL SAMPLE 
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=matrix(0,91,120)
HOR=1

for (j in 1:120) {
  for(Ewind in T0:(T-1)){
    # ROLLING WINDOWS MODELOS 0 
    RW=rwf(RegPri[1:Ewind,j], h = HOR, drift = FALSE, level = c(95))
    FM1[Ewind-T0,j]=RW$mean[HOR]
    
    ForM0 =predict(arima(RegPri[1:Ewind,j],order=c(1,1,1)),HOR)
    FM2[Ewind-T0,j]=ForM0$pred[HOR]
    
    Mod1 =arfima(RegPri[1:Ewind,j],drange=c(0.3,0.5),estim="mle")
    ForM1=forecast(Mod1,h=HOR)
    FM3[Ewind-T0,j]=ForM1$mean[HOR]
  }}

####################

Loss_M1<-matrix(0,91,120)
Loss_M2<-matrix(0,91,120)
Loss_M3<-matrix(0,91,120)
Loss_M4<-matrix(0,91,120)
Loss_M5<-matrix(0,91,120)
Loss_M6<-matrix(0,91,120)
Loss_M7<-matrix(0,91,120)
Loss_M8<-matrix(0,91,120)
Loss_M9<-matrix(0,91,120)
Loss_M10<-matrix(0,91,120)
Loss_M11<-matrix(0,91,120)
Loss_M12<-matrix(0,91,120)
Loss_M13<-matrix(0,91,120)
Loss_M14<-matrix(0,91,120)
Loss_M15<-matrix(0,91,120)

for(j in 1:120){
  Loss_M1[,j]=LossLevel(Price[,j], M1[,j], which = "SE")
  Loss_M2[,j]=LossLevel(Price[,j], M2[,j], which = "SE")
  Loss_M3[,j]=LossLevel(Price[,j], M3[,j], which = "SE")
  Loss_M4[,j]=LossLevel(Price[,j], M4[,j], which = "SE")
  Loss_M5[,j]=LossLevel(Price[,j], M5[,j], which = "SE")
  Loss_M6[,j]=LossLevel(Price[,j], M6[,j], which = "SE")
  Loss_M7[,j]=LossLevel(Price[,j], M7[,j], which = "SE")
  Loss_M8[,j]=LossLevel(Price[,j], M8[,j], which = "SE")
  Loss_M9[,j]=LossLevel(Price[,j], M9[,j], which = "SE")
  Loss_M10[,j]=LossLevel(Price[,j], M10[,j], which = "SE")
  Loss_M11[,j]=LossLevel(Price[,j], M11[,j], which = "SE")
  Loss_M12[,j]=LossLevel(Price[,j], M12[,j], which = "SE")
  Loss_M13[,j]=LossLevel(Price[,j], FM1[,j], which = "SE")
  Loss_M14[,j]=LossLevel(Price[,j], FM2[,j], which = "SE")
  Loss_M15[,j]=LossLevel(Price[,j], FM3[,j], which = "SE")
}

BEST=0
for(j in 1:120){
  LH1=cbind(Loss_M1[,j],Loss_M2[,j],Loss_M3[,j],Loss_M4[,j],Loss_M5[,j],Loss_M6[,j],Loss_M7[,j],Loss_M8[,j],Loss_M9[,j],Loss_M10[,j],Loss_M11[,j],Loss_M12[,j],Loss_M13[,j],Loss_M14[,j],Loss_M15[,j])
  MCS <- MCSprocedure(Loss=LH1,alpha=0.25,B=5000,statistic='TR',verbose = FALSE)
  BEST[j]=which.min(MCS@show[,1])
}

aRMSE1=aRMSE2=aRMSE3=aRMSE4=aRMSE5=aRMSE6=aRMSE7=aRMSE8=aRMSE9=aRMSE10=aRMSE11=aRMSE12=aRMSE13=aRMSE14=aRMSE15=0
for(j in 1:120){
  aRMSE1[j]=sqrt(mean(Loss_M1[,j]))
  aRMSE2[j]=sqrt(mean(Loss_M2[,j]))
  aRMSE3[j]=sqrt(mean(Loss_M3[,j]))
  aRMSE4[j]=sqrt(mean(Loss_M4[,j]))
  aRMSE5[j]=sqrt(mean(Loss_M5[,j]))
  aRMSE6[j]=sqrt(mean(Loss_M6[,j]))
  aRMSE7[j]=sqrt(mean(Loss_M7[,j]))
  aRMSE8[j]=sqrt(mean(Loss_M8[,j]))
  aRMSE9[j]=sqrt(mean(Loss_M9[,j]))
  aRMSE10[j]=sqrt(mean(Loss_M10[,j]))
  aRMSE11[j]=sqrt(mean(Loss_M11[,j]))
  aRMSE12[j]=sqrt(mean(Loss_M12[,j]))
}

RMSE=rbind(mean(aRMSE1),mean(aRMSE2),mean(aRMSE3),mean(aRMSE4),mean(aRMSE5),mean(aRMSE6),mean(aRMSE7),mean(aRMSE8),mean(aRMSE9),mean(aRMSE10),mean(aRMSE11),mean(aRMSE12))

RMSE



#####################################
############ REGION 3 ###############
#####################################

Orig <- read_excel("~R3.xlsx",sheet = 'Orig')
M1a <- read_excel("~R3.xlsx",sheet = 'M1a')
M1b <- read_excel("~R3.xlsx",sheet = 'M1b')
M2a <- read_excel("~R3.xlsx",sheet = 'M2a')
M2b <- read_excel("~R3.xlsx",sheet = 'M2b')
M3a <- read_excel("~R3.xlsx",sheet = 'M3a')
M3b <- read_excel("~R3.xlsx",sheet = 'M3b')
M4a <- read_excel("~R3.xlsx",sheet = 'M4a')
M4b <- read_excel("~R3.xlsx",sheet = 'M4b')
M5a <- read_excel("~R3.xlsx",sheet = 'M5a')
M5b <- read_excel("~R3.xlsx",sheet = 'M5b')
M6a <- read_excel("~R3.xlsx",sheet = 'M6a')
M6b <- read_excel("~R3.xlsx",sheet = 'M6b')

#####################

dP <- data.matrix(Orig)
RegPri <- data.matrix(Orig)
Price<- dP[1006:1096,]

dP <- data.matrix(M1a)
M1<- dP[1:91,]
dP <- data.matrix(M1b)
M2<- dP[1:91,]
dP <- data.matrix(M2a)
M3<- dP[1:91,]
dP <- data.matrix(M2b)
M4<- dP[1:91,]
dP <- data.matrix(M3a)
M5<- dP[1:91,]
dP <- data.matrix(M3b)
M6<- dP[1:91,]
dP <- data.matrix(M4a)
M7<- dP[1:91,]
dP <- data.matrix(M4b)
M8<- dP[1:91,]
dP <- data.matrix(M5a)
M9<- dP[1:91,]
dP <- data.matrix(M5b)
M10<- dP[1:91,]
dP <- data.matrix(M6a)
M11<- dP[1:91,]
dP <- data.matrix(M6b)
M12<- dP[1:91,]

#######################
T =1096 # FULL SAMPLE
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=matrix(0,91,96)
HOR=1

for (j in 1:96) {
  for(Ewind in T0:(T-1)){
    # ROLLING WINDOWS MODELOS 0 
    RW=rwf(RegPri[1:Ewind,j], h = HOR, drift = FALSE, level = c(95))
    FM1[Ewind-T0,j]=RW$mean[HOR]
    
    ForM0 =predict(arima(RegPri[1:Ewind,j],order=c(1,1,1)),HOR)
    FM2[Ewind-T0,j]=ForM0$pred[HOR]
    
    Mod1 =arfima(RegPri[1:Ewind,j],drange=c(0.3,0.5),estim="mle")
    ForM1=forecast(Mod1,h=HOR)
    FM3[Ewind-T0,j]=ForM1$mean[HOR]
  }}

####################

Loss_M1<-matrix(0,91,96)
Loss_M2<-matrix(0,91,96)
Loss_M3<-matrix(0,91,96)
Loss_M4<-matrix(0,91,96)
Loss_M5<-matrix(0,91,96)
Loss_M6<-matrix(0,91,96)
Loss_M7<-matrix(0,91,96)
Loss_M8<-matrix(0,91,96)
Loss_M9<-matrix(0,91,96)
Loss_M10<-matrix(0,91,96)
Loss_M11<-matrix(0,91,96)
Loss_M12<-matrix(0,91,96)
Loss_M13<-matrix(0,91,96)
Loss_M14<-matrix(0,91,96)
Loss_M15<-matrix(0,91,96)

for(j in 1:96){
  Loss_M1[,j]=LossLevel(Price[,j], M1[,j], which = "SE")
  Loss_M2[,j]=LossLevel(Price[,j], M2[,j], which = "SE")
  Loss_M3[,j]=LossLevel(Price[,j], M3[,j], which = "SE")
  Loss_M4[,j]=LossLevel(Price[,j], M4[,j], which = "SE")
  Loss_M5[,j]=LossLevel(Price[,j], M5[,j], which = "SE")
  Loss_M6[,j]=LossLevel(Price[,j], M6[,j], which = "SE")
  Loss_M7[,j]=LossLevel(Price[,j], M7[,j], which = "SE")
  Loss_M8[,j]=LossLevel(Price[,j], M8[,j], which = "SE")
  Loss_M9[,j]=LossLevel(Price[,j], M9[,j], which = "SE")
  Loss_M10[,j]=LossLevel(Price[,j], M10[,j], which = "SE")
  Loss_M11[,j]=LossLevel(Price[,j], M11[,j], which = "SE")
  Loss_M12[,j]=LossLevel(Price[,j], M12[,j], which = "SE")
  Loss_M13[,j]=LossLevel(Price[,j], FM1[,j], which = "SE")
  Loss_M14[,j]=LossLevel(Price[,j], FM2[,j], which = "SE")
  Loss_M15[,j]=LossLevel(Price[,j], FM3[,j], which = "SE")
}

BEST=0
for(j in 1:96){
  LH1=cbind(Loss_M1[,j],Loss_M2[,j],Loss_M3[,j],Loss_M4[,j],Loss_M5[,j],Loss_M6[,j],Loss_M7[,j],Loss_M8[,j],Loss_M9[,j],Loss_M10[,j],Loss_M11[,j],Loss_M12[,j],Loss_M13[,j],Loss_M14[,j],Loss_M15[,j])
  MCS <- MCSprocedure(Loss=LH1,alpha=0.10,B=5000,statistic='Tmax',verbose = FALSE)
  BEST[j]=which.min(MCS@show[,1])
}

aRMSE1=aRMSE2=aRMSE3=aRMSE4=aRMSE5=aRMSE6=aRMSE7=aRMSE8=aRMSE9=aRMSE10=aRMSE11=aRMSE12=aRMSE13=aRMSE14=aRMSE15=0
for(j in 1:96){
  aRMSE1[j]=sqrt(mean(Loss_M1[,j]))
  aRMSE2[j]=sqrt(mean(Loss_M2[,j]))
  aRMSE3[j]=sqrt(mean(Loss_M3[,j]))
  aRMSE4[j]=sqrt(mean(Loss_M4[,j]))
  aRMSE5[j]=sqrt(mean(Loss_M5[,j]))
  aRMSE6[j]=sqrt(mean(Loss_M6[,j]))
  aRMSE7[j]=sqrt(mean(Loss_M7[,j]))
  aRMSE8[j]=sqrt(mean(Loss_M8[,j]))
  aRMSE9[j]=sqrt(mean(Loss_M9[,j]))
  aRMSE10[j]=sqrt(mean(Loss_M10[,j]))
  aRMSE11[j]=sqrt(mean(Loss_M11[,j]))
  aRMSE12[j]=sqrt(mean(Loss_M12[,j]))
}

RMSE=rbind(mean(aRMSE1),mean(aRMSE2),mean(aRMSE3),mean(aRMSE4),mean(aRMSE5),mean(aRMSE6),mean(aRMSE7),mean(aRMSE8),mean(aRMSE9),mean(aRMSE10),mean(aRMSE11),mean(aRMSE12))

RMSE

#####################################
############ REGION 4 ###############
#####################################

Orig <- read_excel("~R4.xlsx",sheet = 'Orig')
M1a <- read_excel("~R4.xlsx",sheet = 'M1a')
M1b <- read_excel("~R4.xlsx",sheet = 'M1b')
M2a <- read_excel("~R4.xlsx",sheet = 'M2a')
M2b <- read_excel("~R4.xlsx",sheet = 'M2b')
M3a <- read_excel("~R4.xlsx",sheet = 'M3a')
M3b <- read_excel("~R4.xlsx",sheet = 'M3b')
M4a <- read_excel("~R4.xlsx",sheet = 'M4a')
M4b <- read_excel("~R4.xlsx",sheet = 'M4b')
M5a <- read_excel("~R4.xlsx",sheet = 'M5a')
M5b <- read_excel("~R4.xlsx",sheet = 'M5b')
M6a <- read_excel("~R4.xlsx",sheet = 'M6a')
M6b <- read_excel("~R4.xlsx",sheet = 'M6b')

#####################

dP <- data.matrix(Orig)
RegPri <- data.matrix(Orig)
Price<- dP[1006:1096,]

dP <- data.matrix(M1a)
M1<- dP[1:91,]
dP <- data.matrix(M1b)
M2<- dP[1:91,]
dP <- data.matrix(M2a)
M3<- dP[1:91,]
dP <- data.matrix(M2b)
M4<- dP[1:91,]
dP <- data.matrix(M3a)
M5<- dP[1:91,]
dP <- data.matrix(M3b)
M6<- dP[1:91,]
dP <- data.matrix(M4a)
M7<- dP[1:91,]
dP <- data.matrix(M4b)
M8<- dP[1:91,]
dP <- data.matrix(M5a)
M9<- dP[1:91,]
dP <- data.matrix(M5b)
M10<- dP[1:91,]
dP <- data.matrix(M6a)
M11<- dP[1:91,]
dP <- data.matrix(M6b)
M12<- dP[1:91,]

#######################
T =1096 # FULL SAMPLE
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=matrix(0,91,24)
HOR=1

for (j in 1:24) {
  for(Ewind in T0:(T-1)){
    # ROLLING WINDOWS MODELOS 0 
    RW=rwf(RegPri[1:Ewind,j], h = HOR, drift = FALSE, level = c(95))
    FM1[Ewind-T0,j]=RW$mean[HOR]
    
    ForM0 =predict(arima(RegPri[1:Ewind,j],order=c(1,1,1)),HOR)
    FM2[Ewind-T0,j]=ForM0$pred[HOR]
    
    Mod1 =arfima(RegPri[1:Ewind,j],drange=c(0.3,0.5),estim="mle")
    ForM1=forecast(Mod1,h=HOR)
    FM3[Ewind-T0,j]=ForM1$mean[HOR]
  }}

####################

Loss_M1<-matrix(0,91,24)
Loss_M2<-matrix(0,91,24)
Loss_M3<-matrix(0,91,24)
Loss_M4<-matrix(0,91,24)
Loss_M5<-matrix(0,91,24)
Loss_M6<-matrix(0,91,24)
Loss_M7<-matrix(0,91,24)
Loss_M8<-matrix(0,91,24)
Loss_M9<-matrix(0,91,24)
Loss_M10<-matrix(0,91,24)
Loss_M11<-matrix(0,91,24)
Loss_M12<-matrix(0,91,24)
Loss_M13<-matrix(0,91,24)
Loss_M14<-matrix(0,91,24)
Loss_M15<-matrix(0,91,24)

for(j in 1:24){
  Loss_M1[,j]=LossLevel(Price[,j], M1[,j], which = "SE")
  Loss_M2[,j]=LossLevel(Price[,j], M2[,j], which = "SE")
  Loss_M3[,j]=LossLevel(Price[,j], M3[,j], which = "SE")
  Loss_M4[,j]=LossLevel(Price[,j], M4[,j], which = "SE")
  Loss_M5[,j]=LossLevel(Price[,j], M5[,j], which = "SE")
  Loss_M6[,j]=LossLevel(Price[,j], M6[,j], which = "SE")
  Loss_M7[,j]=LossLevel(Price[,j], M7[,j], which = "SE")
  Loss_M8[,j]=LossLevel(Price[,j], M8[,j], which = "SE")
  Loss_M9[,j]=LossLevel(Price[,j], M9[,j], which = "SE")
  Loss_M10[,j]=LossLevel(Price[,j], M10[,j], which = "SE")
  Loss_M11[,j]=LossLevel(Price[,j], M11[,j], which = "SE")
  Loss_M12[,j]=LossLevel(Price[,j], M12[,j], which = "SE")
  Loss_M13[,j]=LossLevel(Price[,j], FM1[,j], which = "SE")
  Loss_M14[,j]=LossLevel(Price[,j], FM2[,j], which = "SE")
  Loss_M15[,j]=LossLevel(Price[,j], FM3[,j], which = "SE")
}

BEST=0
for(j in 1:24){
  LH1=cbind(Loss_M1[,j],Loss_M2[,j],Loss_M3[,j],Loss_M4[,j],Loss_M5[,j],Loss_M6[,j],Loss_M7[,j],Loss_M8[,j],Loss_M9[,j],Loss_M10[,j],Loss_M11[,j],Loss_M12[,j])
  MCS <- MCSprocedure(Loss=LH1,alpha=0.20,B=1000,statistic='Tmax',verbose = FALSE)
  BEST[j]=which.min(MCS@show[,1])
}

aRMSE1=aRMSE2=aRMSE3=aRMSE4=aRMSE5=aRMSE6=aRMSE7=aRMSE8=aRMSE9=aRMSE10=aRMSE11=aRMSE12=aRMSE13=aRMSE14=aRMSE15=0
for(j in 1:24){
  aRMSE1[j]=sqrt(mean(Loss_M1[,j]))
  aRMSE2[j]=sqrt(mean(Loss_M2[,j]))
  aRMSE3[j]=sqrt(mean(Loss_M3[,j]))
  aRMSE4[j]=sqrt(mean(Loss_M4[,j]))
  aRMSE5[j]=sqrt(mean(Loss_M5[,j]))
  aRMSE6[j]=sqrt(mean(Loss_M6[,j]))
  aRMSE7[j]=sqrt(mean(Loss_M7[,j]))
  aRMSE8[j]=sqrt(mean(Loss_M8[,j]))
  aRMSE9[j]=sqrt(mean(Loss_M9[,j]))
  aRMSE10[j]=sqrt(mean(Loss_M10[,j]))
  aRMSE11[j]=sqrt(mean(Loss_M11[,j]))
  aRMSE12[j]=sqrt(mean(Loss_M12[,j]))
}

RMSE=rbind(median(aRMSE1),median(aRMSE2),median(aRMSE3),median(aRMSE4),median(aRMSE5),median(aRMSE6),median(aRMSE7),median(aRMSE8),median(aRMSE9),median(aRMSE10),median(aRMSE11),median(aRMSE12))

RMSE
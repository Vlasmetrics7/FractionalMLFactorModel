
function R=forecasting_OneStepAhead

R1_aux=load('R1.mat');
R2_aux=load('R2.mat');
R3_aux=load('R3.mat');
R4_aux=load('R4.mat');
SYSTEM_aux=load('SYSTEM.mat');

for k=1:92
    
R1=R1_aux.R1(1:1004+k,:);
R2=R2_aux.R2(1:1004+k,:);
R3=R3_aux.R3(1:1004+k,:);
R4=R4_aux.R4(1:1004+k,:);
SYSTEM=SYSTEM_aux.SYSTEM(1:1004+k,:);

R1=zscore(R1);R2=zscore(R2);R3=zscore(R3);R4=zscore(R4);

[~,Nr1]=size(R1);
[~,Nr2]=size(R2);
[~,Nr3]=size(R3);
[T,Nr4]=size(R4); N=Nr1+Nr2+Nr3+Nr4;

yaux=[R1 R2 R3 R4]';

% MODEL 1: FRACTIONAL MODEL(1,2,2,2,2)
y_2bar = mean(yaux)';
dy_2bar=fminbnd('extwhittle',-0.5,2,[],y_2bar,fix(T^0.75));
y_g2=yaux';
y_g=fracdiff(y_g2,dy_2bar);

[fhatglob, ~, ~, ~, ~] = blockfactor2level(y_g,[Nr1;Nr2;Nr3;Nr4],1,[2;2;2;2],0.001);

Gl_factor=fracdiff(fhatglob,-dy_2bar);

RGFM1=ols(SYSTEM(1:end),[ones(1004+k,1),Gl_factor(1:end)]);
SystemPriceForM1(k,:) =  RGFM1.beta(1)+ RGFM1.beta(2)*Gl_factor(end);

% MODEL 2: FRACTIONAL MODEL(1,1,1,1,1)
[fhatglobM2, ~, ~, ~, ~] = blockfactor2level(y_g,[Nr1;Nr2;Nr3;Nr4],1,[1;1;1;1],0.001);
Gl_factorM2=fracdiff(fhatglobM2,-dy_2bar);

RGFM2=ols(SYSTEM(1:end),[ones(1004+k,1),Gl_factorM2(1:end)]);
SystemPriceForM2(k,:) =  RGFM2.beta(1)+ RGFM2.beta(2)*Gl_factorM2(end);

% MULTILEVEL STANDARD I(0) MODEL
yML=fracdiff(y_g2,1);
[fhatglobI0, ~, ~, ~, ~] = blockfactor2level(yML,[Nr1;Nr2;Nr3;Nr4],1,[2;2;2;2],0.001);
Gl_factorI0=fracdiff(fhatglobI0,-1);

RGFM3=ols(SYSTEM(1:end),[ones(1004+k,1),Gl_factorI0(1:end)]);
SystemPriceForM3(k,:) =  RGFM3.beta(1)+ RGFM3.beta(2)*Gl_factorI0(end);

% STANDARD I(1) MODEL
 y_g3=yaux';
 Dy=fracdiff(y_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(N)*vectors(:,N);
 CF=Dy*loadings/N;
 CF=fracdiff(CF,-1);
 RGFM4=ols(SYSTEM(1:end),[ones(1004+k,1),CF(1:end)]);
SystemPriceForM4(k,:) =  RGFM4.beta(1)+ RGFM4.beta(2)*CF(end);

% STANDARD I(1) MODEL 4 factors
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(N)*vectors(:,N-1:N);
 CF=Dy*loadings/N;
 CF=fracdiff(CF,-1);
 RGFM5=ols(SYSTEM(1:end),[ones(1004+k,1),CF(1:end,1:2)]);
SystemPriceForM5(k,:) =  RGFM5.beta(1)+ RGFM5.beta(2)*CF(end,1)+...
    RGFM5.beta(3)*CF(end,2);%+ RGFM5.beta(4)*CF(end,3)+RGFM5.beta(5)*CF(end,4);

end

%%%%%%%%%%%%%%% GLOBAL FACTOR VS SYSTEM PRICES %%%%%%%%%%%%%%%%%%%%%%%%%

dsystem=fminbnd('extwhittle',-0.5,2,[],SYSTEM_aux.SYSTEM,fix(1096^0.75));
arma11spec = arima('MALags',1,'ARLags',1);
arma22spec = arima('MALags',2,'ARLags',2);
arma11spec2 = arima(1,1,1);

SystemPriceM1=fracdiff(SYSTEM_aux.SYSTEM,dsystem);

for i=1:92    
    EstARMA11 = estimate(arma11spec,SystemPriceM1(1:1004+i),'Display','off');
    SystemFaux1(i) = forecast(EstARMA11,1,SystemPriceM1(1:1004+i)); 
    
    EstARMA11_2 = estimate(arma11spec2,SYSTEM_aux.SYSTEM(1:1004+i),'Display','off');
    ForPriceM2(i) = forecast(EstARMA11_2,1,SYSTEM_aux.SYSTEM(1:1004+i));
    
    EstARMA22 = estimate(arma22spec,SystemPriceM1(1:1004+i),'Display','off');
    SystemFaux2(i) = forecast(EstARMA22,1,SystemPriceM1(1:1004+i));
end

Sprice1=fracdiff(SystemFaux1',-dsystem);
Sprice2=fracdiff(SystemFaux2',-dsystem);

%%%%%%%% RMSE %%%%%%%

% GLOBAL
PriceRealData2=zscore(SYSTEM_aux.SYSTEM(1006:end));
PriceRealData=SYSTEM_aux.SYSTEM(1006:end);
M1=zscore(Sprice1);M2=zscore(Sprice2);M0=zscore(ForPriceM2);
%M1=Sprice1;M2=Sprice2;M0=ForPriceM2;

for i=1:91
    
RMSE_ARIMA111(i) = (PriceRealData(i) - M0(i)').^2;  
RMSE_ARFIMA1d1(i) = (PriceRealData(i) - M1(i)).^2;
RMSE_ARFIMA2d2(i) = (PriceRealData(i) - M2(i)).^2;

RMSE_MLFM_M1(i) = (PriceRealData(i) - SystemPriceForM1(i)).^2;
RMSE_MLFM_M2(i) = (PriceRealData(i) - SystemPriceForM2(i)).^2;
RMSE_MLFM_M3(i) = (PriceRealData(i) - SystemPriceForM3(i)).^2;
RMSE_MLFM_M4(i) = (PriceRealData(i) - SystemPriceForM4(i)).^2;
RMSE_MLFM_M5(i) = (PriceRealData(i) - SystemPriceForM5(i)).^2;
end

figure(2)
plot(RMSE_ARIMA111,'r:'), hold on, plot(RMSE_ARFIMA1d1,'r:'),hold on,...
    plot(RMSE_ARFIMA2d2,'r:'),hold on,plot(RMSE_MLFM_M1,'k'),hold on,...
    plot(RMSE_MLFM_M2,'k--'),hold on,plot(RMSE_MLFM_M3,'b'),hold on,...
    plot(RMSE_MLFM_M4,'b--'),hold on, plot(RMSE_MLFM_M5,'g--')

losses=[RMSE_ARIMA111',RMSE_ARFIMA1d1',RMSE_ARFIMA2d2',RMSE_MLFM_M1',RMSE_MLFM_M2',RMSE_MLFM_M3',RMSE_MLFM_M4',RMSE_MLFM_M5'];
R.losses=losses;

[includedR,pvalsR,excludedR,includedSQ,pvalsSQ,excludedSQ] = mcs(losses, .05, 5000, 12, 'BLOCK');

R.MC.Rank=includedR;
R.MC.pval=pvalsR;
R.MC.excludedR=excludedR;
R.MC.includedSQ=includedSQ;
R.MC.pvalsSQ=pvalsSQ;
R.MC.excludedSQ=excludedSQ;


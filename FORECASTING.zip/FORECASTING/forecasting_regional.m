
function R=forecasting_regional

R1_aux=load('R1.mat');
R2_aux=load('R2.mat');
R3_aux=load('R3.mat');
R4_aux=load('R4.mat');

R.OrigData.R1=zscore(R1_aux.R1)';R.OrigData.R2=zscore(R2_aux.R2)';
R.OrigData.R3=zscore(R3_aux.R3)';R.OrigData.R4=zscore(R4_aux.R4)';

for k=1:92
    
R1=R1_aux.R1(1+(k-1):1004+k,:);
R2=R2_aux.R2(1+(k-1):1004+k,:);
R3=R3_aux.R3(1+(k-1):1004+k,:);
R4=R4_aux.R4(1+(k-1):1004+k,:);

R1=zscore(R1);R2=zscore(R2);R3=zscore(R3);R4=zscore(R4);

[~,Nr1]=size(R1);
[~,Nr2]=size(R2);
[~,Nr3]=size(R3);
[T,Nr4]=size(R4); N=Nr1+Nr2+Nr3+Nr4;

yaux=[R1 R2 R3 R4]';

y_2bar = mean(yaux)';
dy_2bar=fminbnd('extwhittle',-0.5,2,[],y_2bar,fix(T^0.75));
y_g2=yaux';
y_g=fracdiff(y_g2,dy_2bar);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MODELO 1: FRACTIONAL MODEL(1,2,2,2,2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[fhatglob, fhatreg, ~, ~, ~] = blockfactor2level(y_g,[Nr1;Nr2;Nr3;Nr4],1,[2;2;2;2],0.001);

Gl_factor=fracdiff(fhatglob,-dy_2bar);
R1_factor1=fracdiff(fhatreg(:,1),-dy_2bar);
R1_factor2=fracdiff(fhatreg(:,2),-dy_2bar);
R2_factor1=fracdiff(fhatreg(:,3),-dy_2bar);
R2_factor2=fracdiff(fhatreg(:,4),-dy_2bar);
R3_factor1=fracdiff(fhatreg(:,5),-dy_2bar);
R3_factor2=fracdiff(fhatreg(:,6),-dy_2bar);
R4_factor1=fracdiff(fhatreg(:,7),-dy_2bar);
R4_factor2=fracdiff(fhatreg(:,8),-dy_2bar);

for jj=1:Nr1
RR1=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),Gl_factor(1:end-1),R1_factor1(1:end-1),R1_factor2(1:end-1)]);
R1ForM1a(k,jj) =  RR1.beta(1)+RR1.beta(2)*R1(end,jj) +RR1.beta(3)*Gl_factor(end)+ RR1.beta(4)*R1_factor1(end)+ RR1.beta(5)*R1_factor2(end);

RR12=ols(R1(2:end,jj),[ones(1004,1),Gl_factor(1:end-1),R1_factor1(1:end-1),R1_factor2(1:end-1)]);
R1ForM1b(k,jj) =  RR12.beta(1)+RR12.beta(2)*Gl_factor(end)+ RR12.beta(3)*R1_factor1(end)+ RR12.beta(4)*R1_factor2(end);
end

for jj=1:Nr2
RR2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),Gl_factor(1:end-1),R2_factor1(1:end-1),R2_factor2(1:end-1)]);
R2ForM1a(k,jj) =  RR2.beta(1)+RR2.beta(2)*R2(end,jj) +RR2.beta(3)*Gl_factor(end)+ RR2.beta(4)*R2_factor1(end)+ RR2.beta(5)*R2_factor2(end);

RR22=ols(R2(2:end,jj),[ones(1004,1),Gl_factor(1:end-1),R2_factor1(1:end-1),R2_factor2(1:end-1)]);
R2ForM1b(k,jj) =  RR22.beta(1)+RR22.beta(2)*Gl_factor(end)+ RR22.beta(3)*R2_factor1(end)+ RR22.beta(4)*R2_factor2(end);
end

for jj=1:Nr3
RR3=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),Gl_factor(1:end-1),R3_factor1(1:end-1),R3_factor2(1:end-1)]);
R3ForM1a(k,jj) =  RR3.beta(1)+RR3.beta(2)*R3(end,jj) +RR3.beta(3)*Gl_factor(end)+ RR3.beta(4)*R3_factor1(end)+ RR3.beta(5)*R3_factor2(end);

RR32=ols(R3(2:end,jj),[ones(1004,1),Gl_factor(1:end-1),R3_factor1(1:end-1),R3_factor2(1:end-1)]);
R3ForM1b(k,jj) =  RR32.beta(1)+RR32.beta(2)*Gl_factor(end)+ RR32.beta(3)*R3_factor1(end)+ RR32.beta(4)*R3_factor2(end);
end

for jj=1:Nr4
RR4=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),Gl_factor(1:end-1),R4_factor1(1:end-1),R4_factor2(1:end-1)]);
R4ForM1a(k,jj) =  RR4.beta(1)+RR4.beta(2)*R4(end,jj) +RR4.beta(3)*Gl_factor(end)+ RR4.beta(4)*R4_factor1(end)+ RR4.beta(5)*R4_factor2(end);

RR42=ols(R4(2:end,jj),[ones(1004,1),Gl_factor(1:end-1),R4_factor1(1:end-1),R4_factor2(1:end-1)]);
R4ForM1b(k,jj) =  RR42.beta(1)+RR42.beta(2)*Gl_factor(end)+ RR42.beta(3)*R4_factor1(end)+ RR42.beta(4)*R4_factor2(end);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MODELO 2: FRACTIONAL MODEL(1,1,1,1,1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[fhatglobM2, fhatregM2, ~, ~, ~] = blockfactor2level(y_g,[Nr1;Nr2;Nr3;Nr4],1,[1;1;1;1],0.001);

Gl_factorM2=fracdiff(fhatglobM2,-dy_2bar);
R1_factor1M2=fracdiff(fhatregM2(:,1),-dy_2bar);
R2_factor1M2=fracdiff(fhatregM2(:,2),-dy_2bar);
R3_factor1M2=fracdiff(fhatregM2(:,3),-dy_2bar);
R4_factor1M2=fracdiff(fhatregM2(:,4),-dy_2bar);

for jj=1:Nr1
RR1M2=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),Gl_factorM2(1:end-1),R1_factor1M2(1:end-1)]);
R1ForM2a(k,jj) =  RR1M2.beta(1)+RR1M2.beta(2)*R1(end,jj) +RR1M2.beta(3)*Gl_factorM2(end)+ RR1M2.beta(4)*R1_factor1M2(end);

RR12M2=ols(R1(2:end,jj),[ones(1004,1),Gl_factorM2(1:end-1),R1_factor1M2(1:end-1)]);
R1ForM2b(k,jj) =  RR12M2.beta(1)+RR12M2.beta(2)*Gl_factorM2(end)+ RR12M2.beta(3)*R1_factor1M2(end);
end

for jj=1:Nr2
RR2M2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),Gl_factorM2(1:end-1),R2_factor1M2(1:end-1)]);
R2ForM2a(k,jj) =  RR2M2.beta(1)+RR2M2.beta(2)*R2(end,jj) +RR2M2.beta(3)*Gl_factorM2(end)+ RR2M2.beta(4)*R2_factor1M2(end);

RR22M2=ols(R2(2:end,jj),[ones(1004,1),Gl_factorM2(1:end-1),R2_factor1M2(1:end-1)]);
R2ForM2b(k,jj) =  RR22M2.beta(1)+RR22M2.beta(2)*Gl_factorM2(end)+ RR22M2.beta(3)*R2_factor1M2(end);
end

for jj=1:Nr3
RR3M2=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),Gl_factorM2(1:end-1),R3_factor1M2(1:end-1)]);
R3ForM2a(k,jj) =  RR3M2.beta(1)+RR3M2.beta(2)*R3(end,jj) +RR3M2.beta(3)*Gl_factorM2(end)+ RR3M2.beta(4)*R3_factor1M2(end);

RR32M2=ols(R3(2:end,jj),[ones(1004,1),Gl_factorM2(1:end-1),R3_factor1M2(1:end-1)]);
R3ForM2b(k,jj) =  RR32M2.beta(1)+RR32M2.beta(2)*Gl_factorM2(end)+ RR32M2.beta(3)*R3_factor1M2(end);
end

for jj=1:Nr4
RR4M2=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),Gl_factorM2(1:end-1),R4_factor1M2(1:end-1)]);
R4ForM2a(k,jj) =  RR4M2.beta(1)+RR4M2.beta(2)*R4(end,jj) +RR4M2.beta(3)*Gl_factorM2(end)+ RR4M2.beta(4)*R4_factor1M2(end);

RR42M2=ols(R4(2:end,jj),[ones(1004,1),Gl_factorM2(1:end-1),R4_factor1M2(1:end-1)]);
R4ForM2b(k,jj) =  RR42M2.beta(1)+RR42M2.beta(2)*Gl_factorM2(end)+ RR42M2.beta(3)*R4_factor1M2(end);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MULTILEVEL STANDARD I(0) MODEL
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

yML=fracdiff(y_g2,1);
[fhatglobI, fhatregI, ~, ~, ~] = blockfactor2level(yML,[Nr1;Nr2;Nr3;Nr4],1,[2;2;2;2],0.001);
Gl_factorI=fracdiff(fhatglobI,-1);
R1_factorI1=fracdiff(fhatregI(:,1),-1);
R1_factorI2=fracdiff(fhatregI(:,2),-1);
R2_factorI1=fracdiff(fhatregI(:,3),-1);
R2_factorI2=fracdiff(fhatregI(:,4),-1);
R3_factorI1=fracdiff(fhatregI(:,5),-1);
R3_factorI2=fracdiff(fhatregI(:,6),-1);
R4_factorI1=fracdiff(fhatregI(:,7),-1);
R4_factorI2=fracdiff(fhatregI(:,8),-1);

for jj=1:Nr1
RR1=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),Gl_factorI(1:end-1),R1_factorI1(1:end-1),R1_factorI2(1:end-1)]);
R1ForM3a(k,jj) =  RR1.beta(1)+RR1.beta(2)*R1(end,jj) +RR1.beta(3)*Gl_factorI(end)+ RR1.beta(4)*R1_factorI1(end)+ RR1.beta(5)*R1_factorI2(end);

RR12=ols(R1(2:end,jj),[ones(1004,1),Gl_factorI(1:end-1),R1_factorI1(1:end-1),R1_factorI2(1:end-1)]);
R1ForM3b(k,jj) =  RR12.beta(1)+RR12.beta(2)*Gl_factorI(end)+ RR12.beta(3)*R1_factorI1(end)+ RR12.beta(4)*R1_factorI2(end);
end

for jj=1:Nr2
RR2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),Gl_factorI(1:end-1),R2_factorI1(1:end-1),R2_factorI2(1:end-1)]);
R2ForM3a(k,jj) =  RR2.beta(1)+RR2.beta(2)*R2(end,jj) +RR2.beta(3)*Gl_factorI(end)+ RR2.beta(4)*R2_factorI1(end)+ RR2.beta(5)*R2_factorI2(end);

RR22=ols(R2(2:end,jj),[ones(1004,1),Gl_factorI(1:end-1),R2_factorI1(1:end-1),R2_factorI2(1:end-1)]);
R2ForM3b(k,jj) =  RR22.beta(1)+RR22.beta(2)*Gl_factorI(end)+ RR22.beta(3)*R2_factorI1(end)+ RR22.beta(4)*R2_factorI2(end);
end

for jj=1:Nr3
RR3=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),Gl_factorI(1:end-1),R3_factorI1(1:end-1),R3_factorI2(1:end-1)]);
R3ForM3a(k,jj) =  RR3.beta(1)+RR3.beta(2)*R3(end,jj) +RR3.beta(3)*Gl_factorI(end)+ RR3.beta(4)*R3_factorI1(end)+ RR3.beta(5)*R3_factorI2(end);

RR32=ols(R3(2:end,jj),[ones(1004,1),Gl_factorI(1:end-1),R3_factorI1(1:end-1),R3_factorI2(1:end-1)]);
R3ForM3b(k,jj) =  RR32.beta(1)+RR32.beta(2)*Gl_factorI(end)+ RR32.beta(3)*R3_factorI1(end)+ RR32.beta(4)*R3_factorI2(end);
end

for jj=1:Nr4
RR4=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),Gl_factorI(1:end-1),R4_factorI1(1:end-1),R4_factorI2(1:end-1)]);
R4ForM3a(k,jj) =  RR4.beta(1)+RR4.beta(2)*R4(end,jj) +RR4.beta(3)*Gl_factorI(end)+ RR4.beta(4)*R4_factorI1(end)+ RR4.beta(5)*R4_factorI2(end);

RR42=ols(R4(2:end,jj),[ones(1004,1),Gl_factorI(1:end-1),R4_factorI1(1:end-1),R4_factorI2(1:end-1)]);
R4ForM3b(k,jj) =  RR42.beta(1)+RR42.beta(2)*Gl_factorI(end)+ RR42.beta(3)*R4_factorI1(end)+ RR42.beta(4)*R4_factorI2(end);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD I(1) MODEL: ALL REGIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 y_g3=yaux';
 Dy=fracdiff(y_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(N)*vectors(:,N);
 CF=Dy*loadings/N;
 CF=fracdiff(CF,-1);
 
for jj=1:Nr1
RR1=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),CF(1:end-1)]);
R1ForM4a(k,jj) =  RR1.beta(1)+RR1.beta(2)*R1(end,jj) +RR1.beta(3)*CF(end);

RR12=ols(R1(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R1ForM4b(k,jj) =  RR12.beta(1)+RR12.beta(2)*CF(end);
end

for jj=1:Nr2
RR2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),CF(1:end-1)]);
R2ForM4a(k,jj) =  RR2.beta(1)+RR2.beta(2)*R2(end,jj) +RR2.beta(3)*CF(end);

RR22=ols(R2(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R2ForM4b(k,jj) =  RR22.beta(1)+RR22.beta(2)*CF(end);
end

for jj=1:Nr3
RR3=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),CF(1:end-1)]);
R3ForM4a(k,jj) =  RR3.beta(1)+RR3.beta(2)*R3(end,jj) +RR3.beta(3)*CF(end);

RR32=ols(R3(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R3ForM4b(k,jj) =  RR32.beta(1)+RR32.beta(2)*CF(end);
end

for jj=1:Nr4
RR4=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),CF(1:end-1)]);
R4ForM4a(k,jj) =  RR4.beta(1)+RR4.beta(2)*R4(end,jj) +RR4.beta(3)*CF(end);

RR42=ols(R4(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R4ForM4b(k,jj) =  RR42.beta(1)+RR42.beta(2)*CF(end);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD I(1) MODEL: 3 FACTORS ALL REGIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 y_g3=yaux';
 Dy=fracdiff(y_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(N)*vectors(:,N-2:N);
 CF=Dy*loadings/N;
 CF=fracdiff(CF,-1);
 
for jj=1:Nr1
RR1=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R1ForM5a(k,jj) =  RR1.beta(1)+RR1.beta(2)*R1(end,jj) +RR1.beta(3)*CF(end,1)+RR1.beta(4)*CF(end,2)+RR1.beta(5)*CF(end,3);

RR12=ols(R1(2:end,jj),[ones(1004,1),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R1ForM5b(k,jj) =  RR12.beta(1)+RR12.beta(2)*CF(end,1)+RR12.beta(3)*CF(end,2)+RR12.beta(4)*CF(end,3);
end

for jj=1:Nr2
RR2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R2ForM5a(k,jj) =  RR2.beta(1)+RR2.beta(2)*R2(end,jj) +RR2.beta(3)*CF(end,1)+RR2.beta(4)*CF(end,2)+RR2.beta(5)*CF(end,3);

RR22=ols(R2(2:end,jj),[ones(1004,1),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R2ForM5b(k,jj) =  RR22.beta(1)+RR22.beta(2)*CF(end,1)+RR22.beta(3)*CF(end,2)+RR22.beta(4)*CF(end,3);
end

for jj=1:Nr3
RR3=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R3ForM5a(k,jj) =  RR3.beta(1)+RR3.beta(2)*R3(end,jj) +RR3.beta(3)*CF(end,1)+RR3.beta(4)*CF(end,2)+RR3.beta(5)*CF(end,3);

RR32=ols(R3(2:end,jj),[ones(1004,1),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R3ForM5b(k,jj) =  RR32.beta(1)+RR32.beta(2)*CF(end,1)+RR32.beta(3)*CF(end,2)+RR32.beta(4)*CF(end,3);
end

for jj=1:Nr4
RR4=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R4ForM5a(k,jj) =  RR4.beta(1)+RR4.beta(2)*R4(end,jj) +RR4.beta(3)*CF(end,1)+RR4.beta(4)*CF(end,2)+RR4.beta(5)*CF(end,3);

RR42=ols(R4(2:end,jj),[ones(1004,1),CF(1:end-1,1),CF(1:end-1,2),CF(1:end-1,3)]);
R4ForM5b(k,jj) =  RR42.beta(1)+RR42.beta(2)*CF(end,1)+RR42.beta(3)*CF(end,2)+RR42.beta(4)*CF(end,3);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STANDARD I(1) MODEL: REGION VS REGION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 R1_g3=R1;
 Dy=fracdiff(R1_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(Nr1)*vectors(:,Nr1);
 CF=Dy*loadings/Nr1;
 CF=fracdiff(CF,-1);
 
 for jj=1:Nr1
RR1=ols(R1(2:end,jj),[ones(1004,1),R1(1:end-1,jj),CF(1:end-1)]);
R1ForM6a(k,jj) =  RR1.beta(1)+RR1.beta(2)*R1(end,jj) +RR1.beta(3)*CF(end);

RR12=ols(R1(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R1ForM6b(k,jj) =  RR12.beta(1)+RR12.beta(2)*CF(end);
end

 R2_g3=R2;
 Dy=fracdiff(R2_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(Nr2)*vectors(:,Nr2);
 CF=Dy*loadings/Nr2;
 CF=fracdiff(CF,-1);

for jj=1:Nr2
RR2=ols(R2(2:end,jj),[ones(1004,1),R2(1:end-1,jj),CF(1:end-1)]);
R2ForM6a(k,jj) =  RR2.beta(1)+RR2.beta(2)*R2(end,jj) +RR2.beta(3)*CF(end);

RR22=ols(R2(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R2ForM6b(k,jj) =  RR22.beta(1)+RR22.beta(2)*CF(end);
end

 R3_g3=R3;
 Dy=fracdiff(R3_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(Nr3)*vectors(:,Nr3);
 CF=Dy*loadings/Nr3;
 CF=fracdiff(CF,-1);

for jj=1:Nr3
RR3=ols(R3(2:end,jj),[ones(1004,1),R3(1:end-1,jj),CF(1:end-1)]);
R3ForM6a(k,jj) =  RR3.beta(1)+RR3.beta(2)*R3(end,jj) +RR3.beta(3)*CF(end);

RR32=ols(R3(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R3ForM6b(k,jj) =  RR32.beta(1)+RR32.beta(2)*CF(end);
end

 R4_g3=R4;
 Dy=fracdiff(R4_g3,1);
 [vectors,~] = eig(Dy'*Dy);  
 loadings=sqrt(Nr4)*vectors(:,Nr4);
 CF=Dy*loadings/Nr4;
 CF=fracdiff(CF,-1);

for jj=1:Nr4
RR4=ols(R4(2:end,jj),[ones(1004,1),R4(1:end-1,jj),CF(1:end-1)]);
R4ForM6a(k,jj) =  RR4.beta(1)+RR4.beta(2)*R4(end,jj) +RR4.beta(3)*CF(end);

RR42=ols(R4(2:end,jj),[ones(1004,1),CF(1:end-1)]);
R4ForM6b(k,jj) =  RR42.beta(1)+RR42.beta(2)*CF(end);
end

end

R.M1.R1a=R1ForM1a; R.M1.R1b=R1ForM1b;
R.M1.R2a=R2ForM1a; R.M1.R2b=R2ForM1b;
R.M1.R3a=R3ForM1a; R.M1.R3b=R3ForM1b;
R.M1.R4a=R4ForM1a; R.M1.R4b=R4ForM1b;

R.M2.R1a=R1ForM2a; R.M2.R1b=R1ForM2b;
R.M2.R2a=R2ForM2a; R.M2.R2b=R2ForM2b;
R.M2.R3a=R3ForM2a; R.M2.R3b=R3ForM2b;
R.M2.R4a=R4ForM2a; R.M2.R4b=R4ForM2b;

R.M3.R1a=R1ForM3a; R.M3.R1b=R1ForM3b;
R.M3.R2a=R2ForM3a; R.M3.R2b=R2ForM3b;
R.M3.R3a=R3ForM3a; R.M3.R3b=R3ForM3b;
R.M3.R4a=R4ForM3a; R.M3.R4b=R4ForM3b;

R.M4.R1a=R1ForM4a; R.M4.R1b=R1ForM4b;
R.M4.R2a=R2ForM4a; R.M4.R2b=R2ForM4b;
R.M4.R3a=R3ForM4a; R.M4.R3b=R3ForM4b;
R.M4.R4a=R4ForM4a; R.M4.R4b=R4ForM4b;

R.M5.R1a=R1ForM5a; R.M5.R1b=R1ForM5b;
R.M5.R2a=R2ForM5a; R.M5.R2b=R2ForM5b;
R.M5.R3a=R3ForM5a; R.M5.R3b=R3ForM5b;
R.M5.R4a=R4ForM5a; R.M5.R4b=R4ForM5b;

R.M6.R1a=R1ForM6a; R.M6.R1b=R1ForM6b;
R.M6.R2a=R2ForM6a; R.M6.R2b=R2ForM6b;
R.M6.R3a=R3ForM6a; R.M6.R3b=R3ForM6b;
R.M6.R4a=R4ForM6a; R.M6.R4b=R4ForM6b;


% EXPORTACI�N
% REGION 1
xlswrite('R1.xlsx',R.OrigData.R1','Orig','A2')
xlswrite('R1.xlsx',R.M1.R1a,'M1a','A2')
xlswrite('R1.xlsx',R.M1.R1b,'M1b','A2')
xlswrite('R1.xlsx',R.M2.R1a,'M2a','A2')
xlswrite('R1.xlsx',R.M2.R1b,'M2b','A2')
xlswrite('R1.xlsx',R.M3.R1a,'M3a','A2')
xlswrite('R1.xlsx',R.M3.R1b,'M3b','A2')
xlswrite('R1.xlsx',R.M4.R1a,'M4a','A2')
xlswrite('R1.xlsx',R.M4.R1b,'M4b','A2')
xlswrite('R1.xlsx',R.M5.R1a,'M5a','A2')
xlswrite('R1.xlsx',R.M5.R1b,'M5b','A2')
xlswrite('R1.xlsx',R.M6.R1a,'M6a','A2')
xlswrite('R1.xlsx',R.M6.R1b,'M6b','A2')

% REGION 2
xlswrite('R2.xlsx',R.OrigData.R2','Orig','A2')
xlswrite('R2.xlsx',R.M1.R2a,'M1a','A2')
xlswrite('R2.xlsx',R.M1.R2b,'M1b','A2')
xlswrite('R2.xlsx',R.M2.R2a,'M2a','A2')
xlswrite('R2.xlsx',R.M2.R2b,'M2b','A2')
xlswrite('R2.xlsx',R.M3.R2a,'M3a','A2')
xlswrite('R2.xlsx',R.M3.R2b,'M3b','A2')
xlswrite('R2.xlsx',R.M4.R2a,'M4a','A2')
xlswrite('R2.xlsx',R.M4.R2b,'M4b','A2')
xlswrite('R2.xlsx',R.M5.R2a,'M5a','A2')
xlswrite('R2.xlsx',R.M5.R2b,'M5b','A2')
xlswrite('R2.xlsx',R.M6.R2a,'M6a','A2')
xlswrite('R2.xlsx',R.M6.R2b,'M6b','A2')

% REGION 3
xlswrite('R3.xlsx',R.OrigData.R3','Orig','A2')
xlswrite('R3.xlsx',R.M1.R3a,'M1a','A2')
xlswrite('R3.xlsx',R.M1.R3b,'M1b','A2')
xlswrite('R3.xlsx',R.M2.R3a,'M2a','A2')
xlswrite('R3.xlsx',R.M2.R3b,'M2b','A2')
xlswrite('R3.xlsx',R.M3.R3a,'M3a','A2')
xlswrite('R3.xlsx',R.M3.R3b,'M3b','A2')
xlswrite('R3.xlsx',R.M4.R3a,'M4a','A2')
xlswrite('R3.xlsx',R.M4.R3b,'M4b','A2')
xlswrite('R3.xlsx',R.M5.R3a,'M5a','A2')
xlswrite('R3.xlsx',R.M5.R3b,'M5b','A2')
xlswrite('R3.xlsx',R.M6.R3a,'M6a','A2')
xlswrite('R3.xlsx',R.M6.R3b,'M6b','A2')

% REGION 4
xlswrite('R4.xlsx',R.OrigData.R4','Orig','A2')
xlswrite('R4.xlsx',R.M1.R4a,'M1a','A2')
xlswrite('R4.xlsx',R.M1.R4b,'M1b','A2')
xlswrite('R4.xlsx',R.M2.R4a,'M2a','A2')
xlswrite('R4.xlsx',R.M2.R4b,'M2b','A2')
xlswrite('R4.xlsx',R.M3.R4a,'M3a','A2')
xlswrite('R4.xlsx',R.M3.R4b,'M3b','A2')
xlswrite('R4.xlsx',R.M4.R4a,'M4a','A2')
xlswrite('R4.xlsx',R.M4.R4b,'M4b','A2')
xlswrite('R4.xlsx',R.M5.R4a,'M5a','A2')
xlswrite('R4.xlsx',R.M5.R4b,'M5b','A2')
xlswrite('R4.xlsx',R.M6.R4a,'M6a','A2')
xlswrite('R4.xlsx',R.M6.R4b,'M6b','A2')









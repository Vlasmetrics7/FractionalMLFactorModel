library(fracdiff)
library(forecast)
library(readxl)
library(MCS)

# forecast period HOR
HOR=1

data <- read_excel("~forecastSystemPrice.xlsx",sheet = "series")

T =1096 # FULL SAMPLE
T0=1004 # ROLLING WINDOW
FM1=FM2=FM3=FM4=FM5=FM6=0
eRW=e0=e1=e2=e3=e4=0
Pred.Modelo1<-rep(NA,T)
Pred.Modelo2<-rep(NA,T)
Upp<-rep(NA,T)
Low<-rep(NA,T)
Upp2<-rep(NA,T)
Low2<-rep(NA,T)
for(Ewind in T0:(T-HOR)){
 
  # ROLLING WINDOWS MODEL 0 
  RW=rwf(data$PRICE[(Ewind-T0+1):Ewind], h = HOR, drift = FALSE, level = c(95))
  #RW=rwf(data$PRICE[1:Ewind], h = HOR, drift = FALSE, level = c(95))
  FRW=RW$mean[HOR]
  FM1[Ewind-T0+1]=RW$mean[HOR]
  eRW[Ewind-T0+1]=FRW-data$PRICE[Ewind+HOR]
  
  ForM0 =predict(arima(data$PRICE[(Ewind-T0+1):Ewind],order=c(1,1,1)),HOR)
  Pred.Mod0   =ForM0$pred[HOR]
  FM2[Ewind-T0+1]=ForM0$pred[HOR]
  e0[Ewind-T0+1]=Pred.Mod0-data$PRICE[Ewind+HOR]
  
  
  # ROLLING WINDOWS MODEL 1  
  Mod1 =arfima(data$GLOBAL[(Ewind-T0+1):Ewind],drange=c(0.3,0.5),estim="mle")
  #Mod1 =arfima(data$GLOBAL[1:Ewind],drange=c(0.3,0.5),estim="mle",lambda="auto")
  ForM1=forecast(Mod1,h=HOR)
  Pred.Mod1   =ForM1$mean[HOR]
  FM3[Ewind-T0+1]=ForM1$mean[HOR]

  e1[Ewind-T0+1]=Pred.Mod1-data$PRICE[Ewind+HOR]
  Pred.Modelo1[Ewind]<-Pred.Mod1
  Upp[Ewind] = ForM1$upper
  Low[Ewind] =  ForM1$lower
  
  # ROLLING WINDOWS MODEL 2  
  Mod2 =arfima(data$PRICE[(Ewind-T0+1):Ewind],drange=c(0.2,0.3),estim="mle")
  #Mod2 =arfima(data$PRICE[1:Ewind],drange=c(0.2,0.3),estim="mle")
  ForM2=forecast(Mod2,h=HOR)
  Pred.Mod2   =ForM2$mean[HOR]
  FM4[Ewind-T0+1]=ForM2$mean[HOR]
  
  e2[Ewind-T0+1]=Pred.Mod2-data$PRICE[Ewind+HOR]
  Pred.Modelo2[Ewind]<-Pred.Mod2
  Upp2[Ewind] = ForM2$upper
  Low2[Ewind] =  ForM2$lower
  
    # ROLLING WINDOWS MODEL 3  
  Mod3 = arfima(data$GLOBAL[(Ewind-T0+1):Ewind],drange=c(0.3,0.5),estim="mle",max.p = 1,max.q = 1,lambda="auto")
  #Mod3 = arfima(data$GLOBAL[1:Ewind],drange=c(0.3,0.5),estim="mle",max.p = 1,max.q = 1,lambda="auto")
  ForM3=forecast(Mod3,h=HOR)
  Pred.Mod3   =ForM3$mean[HOR]
  FM5[Ewind-T0+1]=ForM3$mean[HOR]
  
  e3[Ewind-T0+1]=Pred.Mod3-data$PRICE[Ewind+HOR]
  
  # ROLLING WINDOWS MODEL 4  
  Mod4 =arfima(data$PRICE[(Ewind-T0+1):Ewind],drange=c(0.3,0.3),estim="mle",max.p = 1,max.q = 1)
  #Mod4 =arfima(data$PRICE[1:Ewind],drange=c(0.3,0.3),estim="mle",max.p = 1,max.q = 1)
  ForM4=forecast(Mod4,h=HOR)
  Pred.Mod4   =ForM4$mean[HOR]
  FM6[Ewind-T0+1]=ForM4$mean[HOR]
  
  e4[Ewind-T0+1]=Pred.Mod4-data$PRICE[Ewind+HOR]
  }
  

LL_M1=LossLevel(data$PRICE[(T0+HOR):T], FM1[1:(T-T0-HOR+1)], which = "SE")
LL_M2=LossLevel(data$PRICE[(T0+HOR):T], FM2[1:(T-T0-HOR+1)], which = "SE")
LL_M3=LossLevel(data$PRICE[(T0+HOR):T], FM3[1:(T-T0-HOR+1)], which = "SE")
LL_M4=LossLevel(data$PRICE[(T0+HOR):T], FM4[1:(T-T0-HOR+1)], which = "SE")
LL_M5=LossLevel(data$PRICE[(T0+HOR):T], FM5[1:(T-T0-HOR+1)], which = "SE")
LL_M6=LossLevel(data$PRICE[(T0+HOR):T], FM6[1:(T-T0-HOR+1)], which = "SE")

LL_M1AE=LossLevel(data$PRICE[(T0+HOR):T], FM1[1:(T-T0-HOR+1)], which = "AE")
LL_M2AE=LossLevel(data$PRICE[(T0+HOR):T], FM2[1:(T-T0-HOR+1)], which = "AE")
LL_M3AE=LossLevel(data$PRICE[(T0+HOR):T], FM3[1:(T-T0-HOR+1)], which = "AE")
LL_M4AE=LossLevel(data$PRICE[(T0+HOR):T], FM4[1:(T-T0-HOR+1)], which = "AE")
LL_M5AE=LossLevel(data$PRICE[(T0+HOR):T], FM5[1:(T-T0-HOR+1)], which = "AE")
LL_M6AE=LossLevel(data$PRICE[(T0+HOR):T], FM6[1:(T-T0-HOR+1)], which = "AE")

loss=cbind(LL_M1,LL_M2,LL_M3,LL_M4,LL_M5,LL_M6)
MCS <- MCSprocedure(Loss=loss,alpha=0.30,B=5000,statistic='TR')

lossAE=cbind(LL_M1AE,LL_M2AE,LL_M3AE,LL_M4AE,LL_M5AE,LL_M6AE)
MCSAE <- MCSprocedure(Loss=lossAE,alpha=0.10,B=5000,statistic='TR')




  
# BENCHMARK E5  power=2
    
DM1=dm.test(e1,eRW,alternative = "two.sided",h = 1,power = 2)
DM2=dm.test(e1,e0,alternative = "two.sided",h = 1,power = 2)
DM3=dm.test(e1,e2,alternative = "two.sided",h = 1,power = 2)
DM4=dm.test(e1,e3,alternative = "two.sided",h = 1,power = 2)
DM5=dm.test(e1,e4,alternative = "two.sided",h = 1,power = 2)

round(rbind(DM1$p.value,DM2$p.value,DM3$p.value,DM4$p.value,DM5$p.value),3)

DM1=dm.test(e1,eRW,alternative = "less",h = 1,power = 2)
DM2=dm.test(e1,e0,alternative = "less",h = 1,power = 2)
DM3=dm.test(e1,e2,alternative = "less",h = 1,power = 2)
DM4=dm.test(e1,e3,alternative = "less",h = 1,power = 2)
DM5=dm.test(e1,e4,alternative = "less",h = 1,power = 2)

round(rbind(DM1$p.value,DM2$p.value,DM3$p.value,DM4$p.value,DM5$p.value),3)


# BENCHMARK E5  power=1

DM1=dm.test(e1,eRW,alternative = "two.sided",h = 1,power = 1)
DM2=dm.test(e1,e0,alternative = "two.sided",h = 1,power = 1)
DM3=dm.test(e1,e2,alternative = "two.sided",h = 1,power = 1)
DM4=dm.test(e1,e3,alternative = "two.sided",h = 1,power = 1)
DM5=dm.test(e1,e4,alternative = "two.sided",h = 1,power = 1)

round(rbind(DM1$p.value,DM2$p.value,DM3$p.value,DM4$p.value,DM5$p.value),3)

DM1=dm.test(e1,eRW,alternative = "less",h = 1,power = 1)
DM2=dm.test(e1,e0,alternative = "less",h = 1,power = 1)
DM3=dm.test(e1,e2,alternative = "less",h = 1,power = 1)
DM4=dm.test(e1,e3,alternative = "less",h = 1,power = 1)
DM5=dm.test(e1,e4,alternative = "less",h = 1,power = 1)

round(rbind(DM1$p.value,DM2$p.value,DM3$p.value,DM4$p.value,DM5$p.value),3)


# FIGURE

precio=ts(data$PRICE[(T0+HOR-30):T],frequency = 365,start=c(2014,243))

pronos=c(rep(NA,30),FM5)

pronos=ts(pronos,frequency = 365,start=c(2014,243))
Lowr=ts(Low[1004:1095],frequency = 365,start=c(2014,273))
Uppr=ts(Upp[1004:1095],frequency = 365,start=c(2014,273))



plot.ts(precio,main="Expanding windows. Forecasting ",
        xlab="",ylab="", ylim=c(-3, 6))
lines(pronos,col="red",lwd=3,lty=4)
lines(Lowr,col="red",lwd=1,lty=2)
lines(Uppr,col="red",lwd=1,lty=2)
  

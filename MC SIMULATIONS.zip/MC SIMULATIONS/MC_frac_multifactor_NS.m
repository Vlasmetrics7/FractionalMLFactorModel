function MC_frac_multifactor_NS

tic   %Elapsed time is 595.915239 seconds.
 parfor_progress(1000);
parfor i=1:1000
  [dstar_1(i),dr1_1(i),dr2_1(i),dgl_1(i),R2G_1(i),R2_REG1(i),memres_css1(i),memres_elw1(i)]=frac_multifactor(1000,20,1,0.7,0.8,0.5);
  [dstar_2(i),dr1_2(i),dr2_2(i),dgl_2(i),R2G_2(i),R2_REG2(i),memres_css2(i),memres_elw2(i)]=frac_multifactor(1000,20,1,0.8,1,0.6);
  [dstar_3(i),dr1_3(i),dr2_3(i),dgl_3(i),R2G_3(i),R2_REG3(i),memres_css3(i),memres_elw3(i)]=frac_multifactor(1000,20,1,1,1,0.7);
  [dstar_4(i),dr1_4(i),dr2_4(i),dgl_4(i),R2G_4(i),R2_REG4(i),memres_css4(i),memres_elw4(i)]=frac_multifactor(1000,20,1,1.3,1.5,1);
  [dstar_5(i),dr1_5(i),dr2_5(i),dgl_5(i),R2G_5(i),R2_REG5(i),memres_css5(i),memres_elw5(i)]=frac_multifactor(1000,20,1,0.2,0.4,0.6);
  [dstar_6(i),dr1_6(i),dr2_6(i),dgl_6(i),R2G_6(i),R2_REG6(i),memres_css6(i),memres_elw6(i)]=frac_multifactor(1000,20,1,0.3,0.6,0.8);
  [dstar_7(i),dr1_7(i),dr2_7(i),dgl_7(i),R2G_7(i),R2_REG7(i),memres_css7(i),memres_elw7(i)]=frac_multifactor(1000,20,1,0.6,0.8,1);
  [dstar_8(i),dr1_8(i),dr2_8(i),dgl_8(i),R2G_8(i),R2_REG8(i),memres_css8(i),memres_elw8(i)]=frac_multifactor(1000,20,1,1,1,1);
parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1',dstar_2',dstar_3',dstar_4',dstar_5',dstar_6',dstar_7',dstar_8'];
dr1=[dr1_1',dr1_2',dr1_3',dr1_4',dr1_5',dr1_6',dr1_7',dr1_8'];
dr2=[dr2_1',dr2_2',dr2_3',dr2_4',dr2_5',dr2_6',dr2_7',dr2_8'];
dgl=[dgl_1',dgl_2',dgl_3',dgl_4',dgl_5',dgl_6',dgl_7',dgl_8'];
R2G=[R2G_1',R2G_2',R2G_3',R2G_4',R2G_5',R2G_6',R2G_7',R2G_8'];
R2_REG=[R2_REG1',R2_REG2',R2_REG3',R2_REG4',R2_REG5',R2_REG6',R2_REG7',R2_REG8'];
memres_css=[memres_css1',memres_css2',memres_css3',memres_css4',memres_css5',memres_css6',memres_css7',memres_css8'];
memres_elw=[memres_elw1',memres_elw2',memres_elw3',memres_elw4',memres_elw5',memres_elw6',memres_elw7',memres_elw8'];

RES_MC_EXTRAS=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2_REG)',mean(R2G)',...
    mean(memres_css)',mean(memres_elw)']; 
save('RES_MC_EXTRAS_AUX.mat','RES_MC_EXTRAS');    
display('SALE TABLA EXTRA')
clear all
toc


tic   %Elapsed time is 595.915239 seconds.
 parfor_progress(1000);
parfor i=1:1000
  [dstar_1(i),dr1_1(i),dr2_1(i),dgl_1(i),R2G_1(i),R2_REG1(i),memres_css1(i),memres_elw1(i)]=frac_multifactor2(1000,20,1,0.7,0.8,0.5);
  [dstar_2(i),dr1_2(i),dr2_2(i),dgl_2(i),R2G_2(i),R2_REG2(i),memres_css2(i),memres_elw2(i)]=frac_multifactor2(1000,20,1,0.8,1,0.6);
  [dstar_3(i),dr1_3(i),dr2_3(i),dgl_3(i),R2G_3(i),R2_REG3(i),memres_css3(i),memres_elw3(i)]=frac_multifactor2(1000,20,1,1,1,0.7);
  [dstar_4(i),dr1_4(i),dr2_4(i),dgl_4(i),R2G_4(i),R2_REG4(i),memres_css4(i),memres_elw4(i)]=frac_multifactor2(1000,20,1,1.3,1.5,1);
  [dstar_5(i),dr1_5(i),dr2_5(i),dgl_5(i),R2G_5(i),R2_REG5(i),memres_css5(i),memres_elw5(i)]=frac_multifactor2(1000,20,1,0.2,0.4,0.6);
  [dstar_6(i),dr1_6(i),dr2_6(i),dgl_6(i),R2G_6(i),R2_REG6(i),memres_css6(i),memres_elw6(i)]=frac_multifactor2(1000,20,1,0.3,0.6,0.8);
  [dstar_7(i),dr1_7(i),dr2_7(i),dgl_7(i),R2G_7(i),R2_REG7(i),memres_css7(i),memres_elw7(i)]=frac_multifactor2(1000,20,1,0.6,0.8,1);
  [dstar_8(i),dr1_8(i),dr2_8(i),dgl_8(i),R2G_8(i),R2_REG8(i),memres_css8(i),memres_elw8(i)]=frac_multifactor2(1000,20,1,1,1,1);
parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1',dstar_2',dstar_3',dstar_4',dstar_5',dstar_6',dstar_7',dstar_8'];
dr1=[dr1_1',dr1_2',dr1_3',dr1_4',dr1_5',dr1_6',dr1_7',dr1_8'];
dr2=[dr2_1',dr2_2',dr2_3',dr2_4',dr2_5',dr2_6',dr2_7',dr2_8'];
dgl=[dgl_1',dgl_2',dgl_3',dgl_4',dgl_5',dgl_6',dgl_7',dgl_8'];
R2G=[R2G_1',R2G_2',R2G_3',R2G_4',R2G_5',R2G_6',R2G_7',R2G_8'];
R2_REG=[R2_REG1',R2_REG2',R2_REG3',R2_REG4',R2_REG5',R2_REG6',R2_REG7',R2_REG8'];
memres_css=[memres_css1',memres_css2',memres_css3',memres_css4',memres_css5',memres_css6',memres_css7',memres_css8'];
memres_elw=[memres_elw1',memres_elw2',memres_elw3',memres_elw4',memres_elw5',memres_elw6',memres_elw7',memres_elw8'];

RES_MC_EXTRAS2=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2_REG)',mean(R2G)',...
    mean(memres_css)',mean(memres_elw)']; 
save('RES_MC_EXTRAS2__AUX.mat','RES_MC_EXTRAS2');    
display('SALE TABLA EXTRA 2')
clear all
toc
end
           
function  [dy_2bar,dwr1,dwr2,dwgl,R2_G,R2_REG,MEMRES_CSS,MEMRES_ELW]=frac_multifactor(T,Nr,desv,dr,dg,du)
stnr=desv;stdreg=desv;stdglob=desv;
R=2;
Rf=zeros(T,2);
for i=1:2
R1=dgp_arfima(0,0.5,[],T,stdreg,dr,0);
Rf(:,i)= R1;
end
Rf=Rf';
Gl=dgp_arfima(0,0.5,[],T,stdglob,dg,0);
Gf=Gl;
Gf=Gf';

u=zeros(T,2*Nr);
for i=1:2*Nr
R2=dgp_arfima(0,0.1,[],T,stnr,du,0);
u(:,i)= R2;
end

lambda_r1=normrnd(1,1,Nr,1);
lambda_r2=normrnd(1,1,Nr,1);
gamma=normrnd(1,1,2*Nr,1);

L_star = [gamma,[lambda_r1,zeros(Nr,1);zeros(Nr,1),lambda_r2]]; 
F_star = [Gf;Rf];
U_star = u';

yaux = L_star * F_star + U_star; 

%%%% DFRAC MEMORY %%%%%
y_2bar = mean(yaux)';
dy_2bar=fminbnd('extwhittle',-0.5,2,[],y_2bar,fix(T^0.7));

y_g2=yaux';
y_g=fracdiff(y_g2,dy_2bar);
y_r1=yaux(1:Nr,:)';
y_r2=yaux(Nr+1:Nr*R,:)';

[fhatglob, fhatreg, ~, ~, lam] = blockfactor2level(y_g,[Nr;Nr],1,[1;1],0.01);

Gl_factor=fracdiff(fhatglob,-dy_2bar);
R1_factor=fracdiff(fhatreg(:,1),-dy_2bar);
R2_factor=fracdiff(fhatreg(:,2),-dy_2bar);

dwgl = fminbnd('extwhittle',-0.5,2,[],Gl_factor,fix(T^0.7));
dwr1 = fminbnd('extwhittle',-0.5,2,[],R1_factor,fix(T^0.7));
dwr2 = fminbnd('extwhittle',-0.5,2,[],R2_factor,fix(T^0.7));

for i=1:Nr
memres1(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor),d).^2), -2, 2);
memres2(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor),d).^2), -2, 2);
end
memres_r1=mean(memres1); memres_r2=mean(memres2);

F_orig=F_star';
RF=ols(F_orig(:,1),[ones(length(Gl_factor),1),Gl_factor]);
R2_G=RF.rsqr;
RF=ols(F_orig(:,2),[ones(length(Gl_factor),1),R1_factor]);
R2_F1=RF.rsqr;
RF=ols(F_orig(:,3),[ones(length(Gl_factor),1),R2_factor]);
R2_F2=RF.rsqr;

for i=1:Nr
m1(:,i)=(y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor);
m2(:,i)=(y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor);
memres1ELW(i) = fminbnd('extwhittle',-0.5,2,[],m1(:,i),fix(T^0.7));
memres2ELW(i) = fminbnd('extwhittle',-0.5,2,[],m2(:,i),fix(T^0.7));
end

memresELW_r1=mean(memres1ELW);memresELW_r2=mean(memres2ELW);

R2_REG=mean([R2_F1,R2_F2]);

MEMRES_CSS=mean([memres_r1,memres_r2]);

MEMRES_ELW=mean([memresELW_r1,memresELW_r2]);

end

function  [dy_2bar,dwr1,dwr2,dwgl,R2_G,R2_REG,MEMRES_CSS,MEMRES_ELW]=frac_multifactor2(T,Nr,desv,dr,dg,du)
dy_2bar=0;
stnr=desv;stdreg=desv;stdglob=desv;
R=2;
Rf=zeros(T,2);
for i=1:2
R1=dgp_arfima(0,0.5,[],T,stdreg,dr,0);
Rf(:,i)= R1;
end
Rf=Rf';
Gl=dgp_arfima(0,0.5,[],T,stdglob,dg,0);
Gf=Gl;
Gf=Gf';

u=zeros(T,2*Nr);
for i=1:2*Nr
R2=dgp_arfima(0,0.1,[],T,stnr,du,0);
u(:,i)= R2;
end

lambda_r1=normrnd(1,1,Nr,1);
lambda_r2=normrnd(1,1,Nr,1);
gamma=normrnd(1,1,2*Nr,1);

L_star = [gamma,[lambda_r1,zeros(Nr,1);zeros(Nr,1),lambda_r2]]; 
F_star = [Gf;Rf];
U_star = u';

yaux = L_star * F_star + U_star; 

y_g2=yaux';
y_g=y_g2;
y_r1=yaux(1:Nr,:)';
y_r2=yaux(Nr+1:Nr*R,:)';


[fhatglob, fhatreg, ~, ~, lam] = blockfactor2level(y_g,[Nr;Nr],1,[1;1],0.01);

Gl_factor=fhatglob;
R1_factor=fhatreg(:,1);
R2_factor=fhatreg(:,2);

dwgl = fminbnd('extwhittle',-0.5,2,[],Gl_factor,fix(T^0.7));
dwr1 = fminbnd('extwhittle',-0.5,2,[],R1_factor,fix(T^0.7));
dwr2 = fminbnd('extwhittle',-0.5,2,[],R2_factor,fix(T^0.7));

for i=1:Nr
memres1(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor),d).^2), 0, 1.5);
memres2(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor),d).^2), 0, 1.5);
end
memres_r1=mean(memres1); memres_r2=mean(memres2);

F_orig=F_star';
RF=ols(F_orig(:,1),[ones(length(Gl_factor),1),Gl_factor]);
R2_G=RF.rsqr;
RF=ols(F_orig(:,2),[ones(length(Gl_factor),1),R1_factor]);
R2_F1=RF.rsqr;
RF=ols(F_orig(:,3),[ones(length(Gl_factor),1),R2_factor]);
R2_F2=RF.rsqr;

for i=1:Nr
m1(:,i)=(y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor);
m2(:,i)=(y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor);
memres1ELW(i) = fminbnd('extwhittle',-0.5,2,[],m1(:,i),fix(T^0.7));
memres2ELW(i) = fminbnd('extwhittle',-0.5,2,[],m2(:,i),fix(T^0.7));
end

memresELW_r1=mean(memres1ELW);memresELW_r2=mean(memres2ELW);

R2_REG=mean([R2_F1,R2_F2]);

MEMRES_CSS=mean([memres_r1,memres_r2]);

MEMRES_ELW=mean([memresELW_r1,memresELW_r2]);


end

% MC_frac_multifactor_NS
% 100%[===================================================]
% SALE TABLA EXTRA
% Elapsed time is 5870.510833 seconds.
% 100%[===================================================]
% SALE TABLA EXTRA 2
% Elapsed time is 5654.280918 seconds.


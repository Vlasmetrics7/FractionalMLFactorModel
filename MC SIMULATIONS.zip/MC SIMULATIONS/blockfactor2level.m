function [fhatglob, fhatreg, fhatglob0, fhatreg0, lam] = blockfactor2level(y,Nregio,r_glob,r_reg,tol);
%TxN data: y
%Nregio = [nb variables in group 1; nb variables in group 2; ...; nb variables in group g]
%r_reg: nb of group/regional factors (a gx1 vector)
%r_glob: nb global factors

[T,N]=size(y);
g = length(Nregio); 
RegInd = [0 ; cumsum(Nregio)];
RegFno=cumsum(r_reg);
RegFno=[0 ; RegFno];
r = r_glob + r_reg; 
rsum = cumsum(r);
r_reg_sum=[0 ; cumsum(r_reg)];

fi = []; 
for i = 1:g
    [evec,lam] = eigrs2(y(:,RegInd(i)+1:RegInd(i+1))'*y(:,RegInd(i)+1:RegInd(i+1)));
    fi = [fi y(:,RegInd(i)+1:RegInd(i+1))*evec(:,end-r(i)+1:end)];
end 
fi=fi./kron(ones(size(fi,1),1),sqrt(diag(fi'*fi)')); 
 
fhat = [];
nr_glob = [];

for i = 1:g-1 
  C = fi(:,1:rsum(1))'*fi(:,rsum(i)+1:rsum(i+1)); 
  [evec,lam] = eigrs2(C'*C);
  fhat = [fhat fi(:,rsum(i)+1:rsum(i+1))*evec(:,end-r_glob+1:end)];
end

  C = fhat'*fhat; 
  [evec,lam] = eigrs2(C'*C);
  fhatglob = fhat*evec(:,end-r_glob+1:end);
  
u=y-fhatglob*(fhatglob\y);
fhatreg = []; 
for i = 1:g
    [evec,lam] = eigrs2(u(:,RegInd(i)+1:RegInd(i+1))'*u(:,RegInd(i)+1:RegInd(i+1)));
    fhatreg = [fhatreg u(:,RegInd(i)+1:RegInd(i+1))*evec(:,end-r_reg(i)+1:end)];
end 
fhatreg=fhatreg./kron(ones(size(fhatreg,1),1),sqrt(diag(fhatreg'*fhatreg)')); 
fhatglob0=fhatglob;
fhatreg0=fhatreg;

uu1=trace(u'*u);
uu0=1000000000000000000;
iter=0;

while log(uu0)-log(uu1)>0.00001;
   
    lam=zeros(N,r_glob+r_reg_sum(g+1));
    lam(:,1:r_glob)=(fhatglob\y)';
    for i=1:g
        u = y-fhatglob*(fhatglob\y);
        lam(RegInd(i)+1:RegInd(i+1),r_glob+r_reg_sum(i)+1:r_glob+r_reg_sum(i+1))=(fhatreg(:,r_reg_sum(i)+1:r_reg_sum(i+1))\u(:,RegInd(i)+1:RegInd(i+1)))';     
    end
    fhat = (lam\y')';
    fhatglob = fhat(:,1:r_glob);
    fhatreg = fhat(:,r_glob+1:r_glob+g*r_reg);
    fhatreg = fhatreg-fhatglob*(fhatglob\fhatreg); 
 
    uu0 = uu1;
    e = (y - fhat*lam');
    uu1 = trace(e'*e);
    
end

r_reg = mean(r_reg);
n_reg = g*r_reg;
lam_glob=lam(:,1:r_glob);
V = (lam_glob*fhatglob'*fhatglob*lam_glob')/T;
[evec,eigval] = eigrs2(V);
evec=lam_glob'*evec(:,N-r_glob+1:end);
fhatglob = fhatglob*evec;


for i = 1:g
    V = (fhatreg(:,(i-1)*r_reg+1:i*r_reg)'*fhatreg(:,(i-1)*r_reg+1:i*r_reg))/T; 
    [evec,eigval] = eigrs2(V);
    fhatreg(:,(i-1)*r_reg+1:i*r_reg) = fhatreg(:,(i-1)*r_reg+1:i*r_reg)*evec;
end

    lam=zeros(N,r_glob+r_reg_sum(g+1));
    lam(:,1:r_glob)=(fhatglob\y)';
    for i=1:g
        u = y-fhatglob*(fhatglob\y);
        lam(RegInd(i)+1:RegInd(i+1),r_glob+r_reg_sum(i)+1:r_glob+r_reg_sum(i+1))=(fhatreg(:,r_reg_sum(i)+1:r_reg_sum(i+1))\u(:,RegInd(i)+1:RegInd(i+1)))';     
    end

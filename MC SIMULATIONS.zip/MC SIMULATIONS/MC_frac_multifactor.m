 function MC_frac_multifactor

tic   %Elapsed time is 3300 seconds.
 parfor_progress(100);
parfor i=1:100
   [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(150,20,1,2,1,0.2,0.4,0)
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(150,20,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(150,20,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(150,20,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(150,20,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(150,20,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(150,20,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(150,20,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(150,20,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(150,20,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(150,20,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(150,20,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(150,20,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(150,20,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(150,20,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(150,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(150,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(150,20,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(150,20,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(150,20,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(150,20,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(150,20,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(150,20,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(150,20,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(150,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(150,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(150,20,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
 end
 parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

        
RES_MC_150_20=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_150_20.mat','RES_MC_150_20');    
display('SALE TABLA 1')
clear all
toc

tic   %Elapsed time is 595.915239 seconds.
 parfor_progress(100);
parfor i=1:100
  [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(1000,20,1,2,1,0.2,0.4,0);
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(1000,20,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(1000,20,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(1000,20,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(1000,20,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(1000,20,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(1000,20,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(1000,20,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(1000,20,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(1000,20,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(1000,20,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(1000,20,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(1000,20,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(1000,20,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(1000,20,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(1000,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(1000,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(1000,20,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(1000,20,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(1000,20,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(1000,20,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(1000,20,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(1000,20,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(1000,20,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(1000,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(1000,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(1000,20,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

RES_MC_1000_20_prueba=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_1000_20_prueba.mat','RES_MC_1000_20_prueba');    
display('SALE TABLA 2')
clear all
toc

tic   %Elapsed time is 15683.933069 seconds.
 parfor_progress(100);
parfor i=1:100
  [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(5000,20,1,2,1,0.2,0.4,0);
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(5000,20,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(5000,20,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(5000,20,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(5000,20,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(5000,20,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(5000,20,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(5000,20,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(5000,20,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(5000,20,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(5000,20,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(5000,20,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(5000,20,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(5000,20,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(5000,20,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(5000,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(5000,20,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(5000,20,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(5000,20,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(5000,20,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(5000,20,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(5000,20,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(5000,20,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(5000,20,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(5000,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(5000,20,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(5000,20,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

RES_MC_5000_20=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_5000_20.mat','RES_MC_5000_20');    
display('SALE TABLA 3')
clear all
toc

%%%%%%%%%%%%%%% 80 i's  %%%%%%%%%%%%%%%%%%%%

tic   %Elapsed time is 12mil seconds.
 parfor_progress(100);
parfor i=1:100
  [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(150,80,1,2,1,0.2,0.4,0);
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(150,80,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(150,80,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(150,80,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(150,80,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(150,80,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(150,80,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(150,80,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(150,80,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(150,80,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(150,80,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(150,80,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(150,80,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(150,80,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(150,80,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(150,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(150,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(150,80,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(150,80,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(150,80,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(150,80,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(150,80,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(150,80,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(150,80,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(150,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(150,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(150,80,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

RES_MC_150_80=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_150_80.mat','RES_MC_150_80');    
display('SALE TABLA 4')
clear all
toc

tic   %Elapsed time is 595.915239 seconds.
 parfor_progress(100);
parfor i=1:100
  [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(1000,80,1,2,1,0.2,0.4,0);
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(1000,80,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(1000,80,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(1000,80,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(1000,80,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(1000,80,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(1000,80,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(1000,80,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(1000,80,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(1000,80,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(1000,80,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(1000,80,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(1000,80,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(1000,80,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(1000,80,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(1000,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(1000,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(1000,80,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(1000,80,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(1000,80,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(1000,80,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(1000,80,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(1000,80,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(1000,80,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(1000,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(1000,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(1000,80,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

RES_MC_1000_80=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_1000_80.mat','RES_MC_1000_80');    
display('SALE TABLA 5')
clear all
toc

tic   %Elapsed time is  60104.159790 seconds
 parfor_progress(100);
parfor i=1:100
  [dstar_1A(i),dr1_1A(i),dr2_1A(i),dgl_1A(i),R2G_1A(i),R2F1_1A(i),R2F2_1A(i),memres_r1_1A(i),memres_r2_1A(i),memresELW_r1_1A(i),memresELW_r2_1A(i)]=frac_multifactor(5000,80,1,2,1,0.2,0.4,0);
  [dstar_2A(i),dr1_2A(i),dr2_2A(i),dgl_2A(i),R2G_2A(i),R2F1_2A(i),R2F2_2A(i),memres_r1_2A(i),memres_r2_2A(i),memresELW_r1_2A(i),memresELW_r2_2A(i)]=frac_multifactor(5000,80,1,1,1,0.2,0.4,0);
  [dstar_3A(i),dr1_3A(i),dr2_3A(i),dgl_3A(i),R2G_3A(i),R2F1_3A(i),R2F2_3A(i),memres_r1_3A(i),memres_r2_3A(i),memresELW_r1_3A(i),memresELW_r2_3A(i)]=frac_multifactor(5000,80,1,1,2,0.2,0.4,0);
  [dstar_4A(i),dr1_4A(i),dr2_4A(i),dgl_4A(i),R2G_4A(i),R2F1_4A(i),R2F2_4A(i),memres_r1_4A(i),memres_r2_4A(i),memresELW_r1_4A(i),memresELW_r2_4A(i)]=frac_multifactor(5000,80,2,2,1,0.2,0.4,0);
  [dstar_5A(i),dr1_5A(i),dr2_5A(i),dgl_5A(i),R2G_5A(i),R2F1_5A(i),R2F2_5A(i),memres_r1_5A(i),memres_r2_5A(i),memresELW_r1_5A(i),memresELW_r2_5A(i)]=frac_multifactor(5000,80,2,1,1,0.2,0.4,0);
  [dstar_6A(i),dr1_6A(i),dr2_6A(i),dgl_6A(i),R2G_6A(i),R2F1_6A(i),R2F2_6A(i),memres_r1_6A(i),memres_r2_6A(i),memresELW_r1_6A(i),memresELW_r2_6A(i)]=frac_multifactor(5000,80,2,1,2,0.2,0.4,0);
  [dstar_7A(i),dr1_7A(i),dr2_7A(i),dgl_7A(i),R2G_7A(i),R2F1_7A(i),R2F2_7A(i),memres_r1_7A(i),memres_r2_7A(i),memresELW_r1_7A(i),memresELW_r2_7A(i)]=frac_multifactor(5000,80,3.1623,1,2,0.2,0.4,0);
  [dstar_8A(i),dr1_8A(i),dr2_8A(i),dgl_8A(i),R2G_8A(i),R2F1_8A(i),R2F2_8A(i),memres_r1_8A(i),memres_r2_8A(i),memresELW_r1_8A(i),memresELW_r2_8A(i)]=frac_multifactor(5000,80,3.1623,1,2,0.2,0.4,0);
  [dstar_9A(i),dr1_9A(i),dr2_9A(i),dgl_9A(i),R2G_9A(i),R2F1_9A(i),R2F2_9A(i),memres_r1_9A(i),memres_r2_9A(i),memresELW_r1_9A(i),memresELW_r2_9A(i)]=frac_multifactor(5000,80,3.1623,1,2,0.2,0.4,0);

  [dstar_1B(i),dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i),memresELW_r1_1B(i),memresELW_r2_1B(i)]=frac_multifactor(5000,80,1,2,1,0.4,0.8,0.2);
  [dstar_2B(i),dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i),memresELW_r1_2B(i),memresELW_r2_2B(i)]=frac_multifactor(5000,80,1,1,1,0.4,0.8,0.2);
  [dstar_3B(i),dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i),memresELW_r1_3B(i),memresELW_r2_3B(i)]=frac_multifactor(5000,80,1,1,2,0.4,0.8,0.2);
  [dstar_4B(i),dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i),memresELW_r1_4B(i),memresELW_r2_4B(i)]=frac_multifactor(5000,80,2,2,1,0.4,0.8,0.2);
  [dstar_5B(i),dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i),memresELW_r1_5B(i),memresELW_r2_5B(i)]=frac_multifactor(5000,80,2,1,1,0.4,0.8,0.2);
  [dstar_6B(i),dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i),memresELW_r1_6B(i),memresELW_r2_6B(i)]=frac_multifactor(5000,80,2,1,2,0.4,0.8,0.2);
  [dstar_7B(i),dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i),memresELW_r1_7B(i),memresELW_r2_7B(i)]=frac_multifactor(5000,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_8B(i),dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i),memresELW_r1_8B(i),memresELW_r2_8B(i)]=frac_multifactor(5000,80,3.1623,1,2,0.4,0.8,0.2);
  [dstar_9B(i),dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i),memresELW_r1_9B(i),memresELW_r2_9B(i)]=frac_multifactor(5000,80,3.1623,1,2,0.4,0.8,0.2);
  
  
  [dstar_1C(i),dr1_1C(i),dr2_1C(i),dgl_1C(i),R2G_1C(i),R2F1_1C(i),R2F2_1C(i),memres_r1_1C(i),memres_r2_1C(i),memresELW_r1_1C(i),memresELW_r2_1C(i)]=frac_multifactor(5000,80,1,2,1,0.6,0.8,0.4);
  [dstar_2C(i),dr1_2C(i),dr2_2C(i),dgl_2C(i),R2G_2C(i),R2F1_2C(i),R2F2_2C(i),memres_r1_2C(i),memres_r2_2C(i),memresELW_r1_2C(i),memresELW_r2_2C(i)]=frac_multifactor(5000,80,1,1,1,0.6,0.8,0.4);
  [dstar_3C(i),dr1_3C(i),dr2_3C(i),dgl_3C(i),R2G_3C(i),R2F1_3C(i),R2F2_3C(i),memres_r1_3C(i),memres_r2_3C(i),memresELW_r1_3C(i),memresELW_r2_3C(i)]=frac_multifactor(5000,80,1,1,2,0.6,0.8,0.4);
  [dstar_4C(i),dr1_4C(i),dr2_4C(i),dgl_4C(i),R2G_4C(i),R2F1_4C(i),R2F2_4C(i),memres_r1_4C(i),memres_r2_4C(i),memresELW_r1_4C(i),memresELW_r2_4C(i)]=frac_multifactor(5000,80,2,2,1,0.6,0.8,0.4);
  [dstar_5C(i),dr1_5C(i),dr2_5C(i),dgl_5C(i),R2G_5C(i),R2F1_5C(i),R2F2_5C(i),memres_r1_5C(i),memres_r2_5C(i),memresELW_r1_5C(i),memresELW_r2_5C(i)]=frac_multifactor(5000,80,2,1,1,0.6,0.8,0.4);
  [dstar_6C(i),dr1_6C(i),dr2_6C(i),dgl_6C(i),R2G_6C(i),R2F1_6C(i),R2F2_6C(i),memres_r1_6C(i),memres_r2_6C(i),memresELW_r1_6C(i),memresELW_r2_6C(i)]=frac_multifactor(5000,80,2,1,2,0.6,0.8,0.4);
  [dstar_7C(i),dr1_7C(i),dr2_7C(i),dgl_7C(i),R2G_7C(i),R2F1_7C(i),R2F2_7C(i),memres_r1_7C(i),memres_r2_7C(i),memresELW_r1_7C(i),memresELW_r2_7C(i)]=frac_multifactor(5000,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_8C(i),dr1_8C(i),dr2_8C(i),dgl_8C(i),R2G_8C(i),R2F1_8C(i),R2F2_8C(i),memres_r1_8C(i),memres_r2_8C(i),memresELW_r1_8C(i),memresELW_r2_8C(i)]=frac_multifactor(5000,80,3.1623,1,2,0.6,0.8,0.4);
  [dstar_9C(i),dr1_9C(i),dr2_9C(i),dgl_9C(i),R2G_9C(i),R2F1_9C(i),R2F2_9C(i),memres_r1_9C(i),memres_r2_9C(i),memresELW_r1_9C(i),memresELW_r2_9C(i)]=frac_multifactor(5000,80,3.1623,1,2,0.6,0.8,0.4);
  parfor_progress;
end
parfor_progress(0); 
dstar=[dstar_1A',dstar_2A',dstar_3A',dstar_4A',dstar_5A',dstar_6A',dstar_7A',dstar_8A',dstar_9A',...
    dstar_1B',dstar_2B',dstar_3B',dstar_4B',dstar_5B',dstar_6B',dstar_7B',dstar_8B',dstar_9B',...
    dstar_1C',dstar_2C',dstar_3C',dstar_4C',dstar_5C',dstar_6C',dstar_7C',dstar_8C',dstar_9C'];
dr1=[dr1_1A',dr1_2A',dr1_3A',dr1_4A',dr1_5A',dr1_6A',dr1_7A',dr1_8A',dr1_9A',dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B',...
    dr1_1C',dr1_2C',dr1_3C',dr1_4C',dr1_5C',dr1_6C',dr1_7C',dr1_8C',dr1_9C'];
dr2=[dr2_1A',dr2_2A',dr2_3A',dr2_4A',dr2_5A',dr2_6A',dr2_7A',dr2_8A',dr2_9A',dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B',...
    dr2_1C',dr2_2C',dr2_3C',dr2_4C',dr2_5C',dr2_6C',dr2_7C',dr2_8C',dr2_9C'];
dgl=[dgl_1A',dgl_2A',dgl_3A',dgl_4A',dgl_5A',dgl_6A',dgl_7A',dgl_8A',dgl_9A',dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B',...
    dgl_1C',dgl_2C',dgl_3C',dgl_4C',dgl_5C',dgl_6C',dgl_7C',dgl_8C',dgl_9C'];
R2G=[R2G_1A',R2G_2A',R2G_3A',R2G_4A',R2G_5A',R2G_6A',R2G_7A',R2G_8A',R2G_9A',R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B',...
    R2G_1C',R2G_2C',R2G_3C',R2G_4C',R2G_5C',R2G_6C',R2G_7C',R2G_8C',R2G_9C'];
R2F1=[R2F1_1A',R2F1_2A',R2F1_3A',R2F1_4A',R2F1_5A',R2F1_6A',R2F1_7A',R2F1_8A',R2F1_9A',R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B',...
    R2F1_1C',R2F1_2C',R2F1_3C',R2F1_4C',R2F1_5C',R2F1_6C',R2F1_7C',R2F1_8C',R2F1_9C'];
R2F2=[R2F2_1A',R2F2_2A',R2F2_3A',R2F2_4A',R2F2_5A',R2F2_6A',R2F2_7A',R2F2_8A',R2F2_9A',R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B',...
    R2F2_1C',R2F2_2C',R2F2_3C',R2F2_4C',R2F2_5C',R2F2_6C',R2F2_7C',R2F2_8C',R2F2_9C'];
memres_r1=[memres_r1_1A',memres_r1_2A',memres_r1_3A',memres_r1_4A',memres_r1_5A',memres_r1_6A',memres_r1_7A',memres_r1_8A',memres_r1_9A',memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B',...
    memres_r1_1C',memres_r1_2C',memres_r1_3C',memres_r1_4C',memres_r1_5C',memres_r1_6C',memres_r1_7C',memres_r1_8C',memres_r1_9C'];
memres_r2=[memres_r2_1A',memres_r2_2A',memres_r2_3A',memres_r2_4A',memres_r2_5A',memres_r2_6A',memres_r2_7A',memres_r2_8A',memres_r2_9A',memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B',...
    memres_r2_1C',memres_r2_2C',memres_r2_3C',memres_r2_4C',memres_r2_5C',memres_r2_6C',memres_r2_7C',memres_r2_8C',memres_r2_9C'];
memresELW_r1=[memresELW_r1_1A',memresELW_r1_2A',memresELW_r1_3A',memresELW_r1_4A',memresELW_r1_5A',memresELW_r1_6A',memresELW_r1_7A',memresELW_r1_8A',memresELW_r1_9A',...
            memresELW_r1_1B',memresELW_r1_2B',memresELW_r1_3B',memresELW_r1_4B',memresELW_r1_5B',memresELW_r1_6B',memresELW_r1_7B',memresELW_r1_8B',memresELW_r1_9B',...
            memresELW_r1_1C',memresELW_r1_2C',memresELW_r1_3C',memresELW_r1_4C',memresELW_r1_5C',memresELW_r1_6C',memresELW_r1_7C',memresELW_r1_8C',memresELW_r1_9C'];
memresELW_r2=[memresELW_r2_1A',memresELW_r2_2A',memresELW_r2_3A',memresELW_r2_4A',memresELW_r2_5A',memresELW_r2_6A',memresELW_r2_7A',memresELW_r2_8A',memresELW_r2_9A',...
            memresELW_r2_1B',memresELW_r2_2B',memresELW_r2_3B',memresELW_r2_4B',memresELW_r2_5B',memresELW_r2_6B',memresELW_r2_7B',memresELW_r2_8B',memresELW_r2_9B',...
            memresELW_r2_1C',memresELW_r2_2C',memresELW_r2_3C',memresELW_r2_4C',memresELW_r2_5C',memresELW_r2_6C',memresELW_r2_7C',memresELW_r2_8C',memresELW_r2_9C'];

RES_MC_5000_80=[mean(dstar)',mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)',mean(memresELW_r1)',mean(memresELW_r2)'];  
save('RES_MC_5000_80.mat','RES_MC_5000_80');    
display('SALE TABLA 6')
clear all
toc


function  [dy_2barx,dwr1,dwr2,dwgl,R2_G,R2_F1,R2_F2,memres_r1,memres_r2,memresELW_r1,memresELW_r2]=frac_multifactor(T,Nr,stnr,stdreg,stdglob,dr,dg,du)

R=2;
Rf=zeros(T,2);

UR1=normrnd(0,stdreg,T,2);
for i=1:2
    R1=fastfrac(UR1(:,i),-dr);
%R1=dgp_arfima(0,0.5,[],T+50,stdreg,dr,0);
Rf(:,i)= R1;
end
Rf=Rf';

UG=normrnd(0,stdglob,T,1);
Gl=fastfrac(UG,-dg);
%Gl=dgp_arfima(0,0.5,[],T+50,stdglob,dg,0);
Gf=Gl';
%Gf=Gf';

u=zeros(T,2*Nr);
Uu=normrnd(0,stnr,T,2*Nr);
for i=1:2*Nr
R2=fastfrac(Uu(:,i),-du);
%R2=dgp_arfima(0,0.1,[],T+50,stnr,du,0);
u(:,i)= R2;
end

lambda_r1=normrnd(1,1,Nr,1);
lambda_r2=normrnd(1,1,Nr,1);
gamma=normrnd(1,1,2*Nr,1);

L_star = [gamma,[lambda_r1,zeros(Nr,1);zeros(Nr,1),lambda_r2]]; 
F_star = [Gf;Rf];
U_star = u';

yaux = L_star * F_star + U_star; 

%%%% DFRAC MEMORY %%%%%
y_2bar = mean(yaux)';
dy_2barx=fminbnd('extwhittle',-0.5,2,[],y_2bar,fix(T^0.6));
dy_2bar=max(dr,dg);

y_g2=yaux';
y_g=fracdiff(y_g2,dy_2bar);
y_r1=yaux(1:Nr,:)';
y_r2=yaux(Nr+1:Nr*R,:)';

[fhatglob, fhatreg, ~, ~, lam] = blockfactor2level(y_g,[Nr;Nr],1,[1;1],0.01);

Gl_factor=fracdiff(fhatglob,-dy_2bar);
R1_factor=fracdiff(fhatreg(:,1),-dy_2bar);
R2_factor=fracdiff(fhatreg(:,2),-dy_2bar);

dwgl = fminbnd('extwhittle',-0.5,2,[],Gl_factor,fix(T^0.6));
dwr1 = fminbnd('extwhittle',-0.5,2,[],R1_factor,fix(T^0.6));
dwr2 = fminbnd('extwhittle',-0.5,2,[],R2_factor,fix(T^0.6));

for i=1:Nr
memres1(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor),d).^2), -2, 2);
memres2(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor),d).^2), -2, 2);
end
memres_r1=mean(memres1); memres_r2=mean(memres2);

F_orig=F_star';
RF=ols(F_orig(:,1),[ones(length(Gl_factor),1),Gl_factor]);
R2_G=RF.rsqr;
RF=ols(F_orig(:,2),[ones(length(Gl_factor),1),R1_factor]);
R2_F1=RF.rsqr;
RF=ols(F_orig(:,3),[ones(length(Gl_factor),1),R2_factor]);
R2_F2=RF.rsqr;

for i=1:Nr
m1(:,i)=(y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor);
m2(:,i)=(y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor);
memres1ELW(i) = fminbnd('extwhittle',-0.5,2,[],m1(:,i),fix(T^0.6));
memres2ELW(i) = fminbnd('extwhittle',-0.5,2,[],m2(:,i),fix(T^0.6));
end

memresELW_r1=mean(memres1ELW);memresELW_r2=mean(memres2ELW);



% MC_frac_multifactor
% 100%[===================================================]
% SALE TABLA 1
% Elapsed time is 1524.855164 seconds.
% 100%[===================================================]
% SALE TABLA 2
% Elapsed time is 3093.979102 seconds.
% 100%[===================================================]
% SALE TABLA 3
% Elapsed time is 16282.043467 seconds.
% 100%[===================================================]
% SALE TABLA 4
% Elapsed time is 5812.679643 seconds.
% 100%[===================================================]
% SALE TABLA 5
% % Elapsed time is 11873.360665 seconds.
% Starting parallel pool (parp
% 100%[===================================================]
% SALE TABLA 6
% Elapsed time is 62601.162914 seconds.
% IdleTimeout has been reached.
% Parallel pool using the 'local' profile is shutting down.



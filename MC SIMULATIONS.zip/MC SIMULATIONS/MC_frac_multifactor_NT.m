function MC_frac_multifactor_NT
tic
 parfor_progress(1000);
parfor i=1:1000
  [dr1_1B(i),dr2_1B(i),dgl_1B(i),R2G_1B(i),R2F1_1B(i),R2F2_1B(i),memres_r1_1B(i),memres_r2_1B(i)]=frac_multifactor(150,300,1,2,1,0.4,0.8,0.2);
  [dr1_2B(i),dr2_2B(i),dgl_2B(i),R2G_2B(i),R2F1_2B(i),R2F2_2B(i),memres_r1_2B(i),memres_r2_2B(i)]=frac_multifactor(150,300,1,1,1,0.4,0.8,0.2);
  [dr1_3B(i),dr2_3B(i),dgl_3B(i),R2G_3B(i),R2F1_3B(i),R2F2_3B(i),memres_r1_3B(i),memres_r2_3B(i)]=frac_multifactor(150,300,1,1,2,0.4,0.8,0.2);
  [dr1_4B(i),dr2_4B(i),dgl_4B(i),R2G_4B(i),R2F1_4B(i),R2F2_4B(i),memres_r1_4B(i),memres_r2_4B(i)]=frac_multifactor(150,300,2,2,1,0.4,0.8,0.2);
  [dr1_5B(i),dr2_5B(i),dgl_5B(i),R2G_5B(i),R2F1_5B(i),R2F2_5B(i),memres_r1_5B(i),memres_r2_5B(i)]=frac_multifactor(150,300,2,1,1,0.4,0.8,0.2);
  [dr1_6B(i),dr2_6B(i),dgl_6B(i),R2G_6B(i),R2F1_6B(i),R2F2_6B(i),memres_r1_6B(i),memres_r2_6B(i)]=frac_multifactor(150,300,2,1,2,0.4,0.8,0.2);
  [dr1_7B(i),dr2_7B(i),dgl_7B(i),R2G_7B(i),R2F1_7B(i),R2F2_7B(i),memres_r1_7B(i),memres_r2_7B(i)]=frac_multifactor(150,300,3.1623,1,2,0.4,0.8,0.2);
  [dr1_8B(i),dr2_8B(i),dgl_8B(i),R2G_8B(i),R2F1_8B(i),R2F2_8B(i),memres_r1_8B(i),memres_r2_8B(i)]=frac_multifactor(150,300,3.1623,1,2,0.4,0.8,0.2);
  [dr1_9B(i),dr2_9B(i),dgl_9B(i),R2G_9B(i),R2F1_9B(i),R2F2_9B(i),memres_r1_9B(i),memres_r2_9B(i)]=frac_multifactor(150,300,3.1623,1,2,0.4,0.8,0.2);
  
  parfor_progress;
end
parfor_progress(0); 
dr1=[dr1_1B',dr1_2B',dr1_3B',dr1_4B',dr1_5B',dr1_6B',dr1_7B',dr1_8B',dr1_9B'];
dr2=[dr2_1B',dr2_2B',dr2_3B',dr2_4B',dr2_5B',dr2_6B',dr2_7B',dr2_8B',dr2_9B'];
dgl=[dgl_1B',dgl_2B',dgl_3B',dgl_4B',dgl_5B',dgl_6B',dgl_7B',dgl_8B',dgl_9B'];
R2G=[R2G_1B',R2G_2B',R2G_3B',R2G_4B',R2G_5B',R2G_6B',R2G_7B',R2G_8B',R2G_9B'];
R2F1=[R2F1_1B',R2F1_2B',R2F1_3B',R2F1_4B',R2F1_5B',R2F1_6B',R2F1_7B',R2F1_8B',R2F1_9B'];
R2F2=[R2F2_1B',R2F2_2B',R2F2_3B',R2F2_4B',R2F2_5B',R2F2_6B',R2F2_7B',R2F2_8B',R2F2_9B'];
memres_r1=[memres_r1_1B',memres_r1_2B',memres_r1_3B',memres_r1_4B',memres_r1_5B',memres_r1_6B',memres_r1_7B',memres_r1_8B',memres_r1_9B'];
memres_r2=[memres_r2_1B',memres_r2_2B',memres_r2_3B',memres_r2_4B',memres_r2_5B',memres_r2_6B',memres_r2_7B',memres_r2_8B',memres_r2_9B'];

RES_MC_150_300=[mean(dr1)',mean(dr2)',mean(dgl)',mean(R2G)',mean(R2F1)',mean(R2F2)',mean(memres_r1)',mean(memres_r2)'];  
save('RES_MC_150_300.mat','RES_MC_150_300');    
display('SALE TABLA 1')
clear all
toc



function  [dwr1,dwr2,dwgl,R2_G,R2_F1,R2_F2,memres_r1,memres_r2]=frac_multifactor(T,Nr,stnr,stdreg,stdglob,dr,dg,du)

R=2;
Rf=zeros(T,2);
for i=1:2
R1=dgp_arfima(0,0.5,[],T,stdreg,dr,0);
Rf(:,i)= R1;
end
Rf=Rf';
Gl=dgp_arfima(0,0.5,[],T,stdglob,dg,0);
Gf=Gl;
Gf=Gf';

u=zeros(T,2*Nr);
for i=1:2*Nr
R2=dgp_arfima(0,0.1,[],T,stnr,du,0);
u(:,i)= R2;
end

lambda_r1=normrnd(1,1,Nr,1);
lambda_r2=normrnd(1,1,Nr,1);
gamma=normrnd(1,1,2*Nr,1);

L_star = [gamma,[lambda_r1,zeros(Nr,1);zeros(Nr,1),lambda_r2]]; 
F_star = [Gf;Rf];
U_star = u';

yaux = L_star * F_star + U_star; 

y_g=yaux';
y_r1=yaux(1:Nr,:)';
y_r2=yaux(Nr+1:Nr*R,:)';

[fhatglob, fhatreg, fhatglob0, fhatreg0, lam] = blockfactor2level(y_g,[Nr;Nr],1,[1;1],0.01);

Gl_factor=fhatglob;
R1_factor=fhatreg(:,1);
R2_factor=fhatreg(:,2);

dwgl = fminbnd('extwhittle',-0.5,2,[],Gl_factor,fix(T^0.7));
dwr1 = fminbnd('extwhittle',-0.5,2,[],R1_factor,fix(T^0.7));
dwr2 = fminbnd('extwhittle',-0.5,2,[],R2_factor,fix(T^0.7));

parfor i=1:Nr
memres1(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor),d).^2), -2, 2);
memres2(i)=fminbnd(@(d)(1/(T))*sum(fastfrac((y_r2(:,i)-lam(Nr+i,1)*Gl_factor-lam(Nr+i,3)*R2_factor),d).^2), -2, 2);
end
memres_r1=mean(memres1); memres_r2=mean(memres2);

F_orig=F_star';
RF=ols(F_orig(:,1),[ones(length(Gl_factor),1),Gl_factor]);
R2_G=RF.rsqr;
RF=ols(F_orig(:,2),[ones(length(Gl_factor),1),R1_factor]);
R2_F1=RF.rsqr;
RF=ols(F_orig(:,3),[ones(length(Gl_factor),1),R2_factor]);
R2_F2=RF.rsqr;

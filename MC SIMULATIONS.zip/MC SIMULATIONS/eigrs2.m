function [evec,lamv]=eigrs2(y);
% sort eigenvalues and coresponding eigenvectors in ascending order
% Output: eigenvalues as column vector in ascending order
[evec,lam]=eig(y);
lamvh=diag(lam);
[lamv,I]=sort(lamvh);
evec=evec(:,I);

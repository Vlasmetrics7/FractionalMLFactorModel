function Results=fracmlf_elec

R1_aux=load('R1.mat');R1=R1_aux.R1;% R1=fracdiff(R1,1);
R2_aux=load('R2.mat');R2=R2_aux.R2;%R2=fracdiff(R2,1);
R3_aux=load('R3.mat');R3=R3_aux.R3;%R3=fracdiff(R3,1);
R4_aux=load('R4.mat');R4=R4_aux.R4;%R4=fracdiff(R4,1);
SYSTEM_aux=load('SYSTEM.mat');SYSTEM=SYSTEM_aux.SYSTEM;%SYSTEM=diff(SYSTEM);
Results.system=SYSTEM;

R1=zscore(R1);R2=zscore(R2);R3=zscore(R3);R4=zscore(R4);

[T,Nr1]=size(R1);
[T,Nr2]=size(R2);
[T,Nr3]=size(R3);
[T,Nr4]=size(R4);

yaux=[R1 R2 R3 R4]';

y_2bar = mean(yaux)';
dy_2bar=fminbnd('extwhittle',-0.5,2,[],y_2bar,fix(T^0.7));
y_g2=yaux';
y_g=fracdiff(y_g2,dy_2bar);

[fhatglob, fhatreg, fhatglob0, ~, lam] = blockfactor2level(y_g,[Nr1;Nr2;Nr3;Nr4],1,[2;2;2;2],0.01);

Results.loading=lam;
Results.fhatglob0=fhatglob0;

Gl_factor=fracdiff(fhatglob(:,1),-dy_2bar);
R1_factor1=fracdiff(fhatreg(:,1),-dy_2bar);
R1_factor2=fracdiff(fhatreg(:,2),-dy_2bar);
R2_factor1=fracdiff(fhatreg(:,3),-dy_2bar);
R2_factor2=fracdiff(fhatreg(:,4),-dy_2bar);
R3_factor1=fracdiff(fhatreg(:,5),-dy_2bar);
R3_factor2=fracdiff(fhatreg(:,6),-dy_2bar);
R4_factor1=fracdiff(fhatreg(:,7),-dy_2bar);
R4_factor2=fracdiff(fhatreg(:,8),-dy_2bar);

Results.factors=[Gl_factor,R1_factor1,R1_factor2,...
    R2_factor1,R2_factor2,R3_factor1,R3_factor2,...
    R4_factor1,R4_factor2];

m2 = fix(T^0.7);
d_global = fminbnd('extwhittle',-0.5,2,[],Gl_factor,m2);
d_fR11 = fminbnd('extwhittle',-0.5,2,[],R1_factor1,m2);
d_fR12 = fminbnd('extwhittle',-0.5,2,[],R1_factor2,m2);
d_fR21 = fminbnd('extwhittle',-0.5,2,[],R2_factor1,m2);
d_fR22 = fminbnd('extwhittle',-0.5,2,[],R2_factor2,m2);
d_fR31 = fminbnd('extwhittle',-0.5,2,[],R3_factor1,m2);
d_fR32 = fminbnd('extwhittle',-0.5,2,[],R3_factor2,m2);
d_fR41 = fminbnd('extwhittle',-0.5,2,[],R4_factor1,m2);
d_fR42 = fminbnd('extwhittle',-0.5,2,[],R4_factor2,m2);

Results.mem_factor_reg=[d_global,d_fR11,d_fR12,d_fR21,d_fR22,d_fR31,d_fR32,d_fR41,d_fR42];

for i=1:Nr1
memres_R1(i)=fminbnd(@(d)(1/(T))*sum(fracdiff((R1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor1-lam(i,3)*R1_factor2),d).^2), 0, 1.5);
end

for i=1:Nr2
memres_R2(i)=fminbnd(@(d)(1/(T))*sum(fracdiff((R2(:,i)-lam(Nr1+i,1)*Gl_factor-lam(Nr1+i,4)*R2_factor1-lam(Nr1+i,5)*R2_factor2),d).^2), 0, 1.5);
end

for i=1:Nr3
memres_R3(i)=fminbnd(@(d)(1/(T))*sum(fracdiff((R3(:,i)-lam((Nr1+Nr2)+i,1)*Gl_factor-lam((Nr1+Nr2)+i,6)*R3_factor1-lam((Nr1+Nr2)+i,7)*R3_factor2),d).^2), 0, 1.5);
end

for i=1:Nr4
memres_R4(i)=fminbnd(@(d)(1/(T))*sum(fracdiff((R4(:,i)-lam((Nr1+Nr2+Nr3)+i,1)*Gl_factor-lam((Nr1+Nr2+Nr3)+i,8)*R4_factor1-lam((Nr1+Nr2+Nr3)+i,9)*R4_factor2),d).^2), 0, 1.5);
end

Results.memresR1=[memres_R1'];Results.memresR2=[memres_R2'];Results.memresR3=[memres_R3'];Results.memresR4=[memres_R4'];
Results.memres_mean=[mean(memres_R1),mean(memres_R2),mean(memres_R3),mean(memres_R4)];

for i=1:Nr1
mod1(:,i)=(R1(:,i)-lam(i,1)*Gl_factor-lam(i,2)*R1_factor1-lam(i,3)*R1_factor2);
memres1ELW(i) = fminbnd('extwhittle',-0.5,2,[],mod1(:,i),fix(T^0.75));
end

for i=1:Nr2
mod2(:,i)=(R2(:,i)-lam(Nr1+i,1)*Gl_factor-lam(Nr1+i,4)*R2_factor1-lam(Nr1+i,5)*R2_factor2);
memres2ELW(i) = fminbnd('extwhittle',-0.5,2,[],mod2(:,i),fix(T^0.75));
end

for i=1:Nr3
mod3(:,i)=(R3(:,i)-lam((Nr1+Nr2)+i,1)*Gl_factor-lam((Nr1+Nr2)+i,6)*R3_factor1-lam((Nr1+Nr2)+i,7)*R3_factor2);
memres3ELW(i) = fminbnd('extwhittle',-0.5,2,[],mod3(:,i),fix(T^0.75));
end

for i=1:Nr4
mod4(:,i)=(R4(:,i)-lam((Nr1+Nr2+Nr3)+i,1)*Gl_factor-lam((Nr1+Nr2+Nr3)+i,8)*R4_factor1-lam((Nr1+Nr2+Nr3)+i,9)*R4_factor2);
memres4ELW(i) = fminbnd('extwhittle',-0.5,2,[],mod4(:,i),fix(T^0.75));
end

Results.memres1ELW=[memres1ELW'];Results.memres2ELW=[memres2ELW'];Results.memres3ELW=[memres3ELW'];Results.memres4ELW=[memres4ELW'];
Results.memresELW_mean=[mean(memres1ELW),mean(memres2ELW),mean(memres3ELW),mean(memres4ELW)];

memglob=[Results.mem_factor_reg(1) NaN NaN NaN NaN NaN NaN NaN NaN];
memreg=[NaN Results.mem_factor_reg(2:end)];
memres=[NaN,Results.memres_mean];

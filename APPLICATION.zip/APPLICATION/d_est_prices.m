function R=d_est_prices(ff2)

R1_aux=load('R1.mat');R1=R1_aux.R1;
R2_aux=load('R2.mat');R2=R2_aux.R2;
R3_aux=load('R3.mat');R3=R3_aux.R3;
R4_aux=load('R4.mat');R4=R4_aux.R4;

[~,Nr1]=size(R1);
[~,Nr2]=size(R2);
[~,Nr3]=size(R3);
[~,Nr4]=size(R4);

%%%%%%%%%%%%%%%%%%% LONG MEMORY ESTIMATES %%%%%%%%%%%%%%%%%%% 
options = optimset('fminbnd');T2=1096;
m2 = fix(T2^ff2);	
dR1=zeros(1,Nr1);
dR2=zeros(1,Nr2);
dR3=zeros(1,Nr3);
dR4=zeros(1,Nr4);

for i=1:Nr1
dR1(i) = fminbnd('extwhittle',-0.5,2,[],R1(:,i),m2);
end

for i=1:Nr2
dR2(i) = fminbnd('extwhittle',-0.5,2,[],R2(:,i),m2);
end

for i=1:Nr3
dR3(i) = fminbnd('extwhittle',-0.5,2,[],R3(:,i),m2);
end

for i=1:Nr4
dR4(i) = fminbnd('extwhittle',-0.5,2,[],R4(:,i),m2);
end

R.R1=dR1';R.R2=dR2';R.R3=dR3';R.R4=dR4';



